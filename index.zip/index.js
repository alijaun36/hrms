/**
 * Nodvel framework
 * @version 1.1.0
 * Feb, 2022
 */
global.__skip_server = false
const Application = require('./core/application.js')
new Application().run()