/**
 * @class Instance
 * @description database orm for nodvel
 */
 module.exports = class Instance {

    constructor() {
        
    }

 }