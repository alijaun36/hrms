/**
 * @class SqlHandle
 * @description handles mysql queries
 */
 module.exports = class SqlHandle {

    constructor() {
        
    }

    select() {}

    where() {}

    orWhere() {}

    sort() {}

    groupBy() {}

    limit() {}

    offset() {}

    create() {}

    insert() {}

    update() {}

    delete() {}

    whereHas() {}

    with() {}

 }