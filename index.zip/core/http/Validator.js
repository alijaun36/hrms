/**
 * @class Validator
 * @description handle validation of request and filters
 */
module.exports = class Validator {
  constructor(res) {
    this.res = res
    this.errors = []
  }

  /**
   * @method validate
   * @param schema jsonObject
   * @returns {array} errors
   */
  async validate(schema, messages) {
    messages = messages === undefined ? [] : messages

    let validation_class = resolve("core.http.Validations", this.res)
    let errors = []

    // Generating fields
    let fields = validation_class.generateFields(schema, messages)

    // Generating rules
    let rules = validation_class.generateRules(fields)

    // Applying rules
    for (let i = 0; i < rules.length; i++) {
      let rule = rules[i]
      // console.log(rule)

      validation_class.required(rule)
      validation_class.same(rule, rules)
      validation_class.string(rule)
      validation_class.number(rule)
      validation_class.min(rule)
      validation_class.max(rule)
      validation_class.email(rule)
      validation_class.format(rule)
      validation_class.enum(rule)
      validation_class.mongoId(rule)
      validation_class.file(rule)
      await validation_class.unique(rule)
      await validation_class.exists(rule)

      if (rule.name == "array" && rule.target) {
        await validation_class.parseArrayRules(rule, async (rule) => {
          validation_class.required(rule)
          validation_class.string(rule)
          validation_class.number(rule)
          validation_class.email(rule)
          validation_class.format(rule)
          validation_class.enum(rule)
          validation_class.mongoId(rule)
          validation_class.file(rule)
        })
      }

      errors = validation_class.collectErrors()
    }

    console.log(errors)
    return errors
  }

  filter(schema) {
    let validation_class = resolve("core.http.Validations", this.res)

    // Generating fields
    let fields = validation_class.generateFields(schema)
    // console.log(fields)
    let rules = validation_class.generateRules(fields)

    // console.log(rules)

    // Applying rules
    let find_data = {}
    let projection_data = {}
    let query_data = {}
    for (let i = 0; i < rules.length; i++) {
      let rule = rules[i]

      if (rule.name == "projection") {
        // console.log('PROJECTION: ', rule)
        projection_data[rule.source] = parseInt(rule.type)
      }
      if (rule.name == "likes") {
        // console.log('LIKES: ', rule)
        let value = rule.target ? rule.target : ""
        if (value) {
          if (find_data["$or"] === undefined) find_data["$or"] = []
          for (let i = 0; i < rule.values.length; i++) {
            find_data["$or"].push({
              [rule.values[i]]: new RegExp(value + ".*", "i"),
            })
          }
        }
      }
      if (rule.name == "like") {
        // console.log("LIKE: ", rule)
        let value = rule.target ? rule.target : ""
        if (find_data["$or"] === undefined) find_data["$or"] = []
        find_data["$or"].push({ [rule.source]: new RegExp(value + ".*", "i") })
      }
      if (rule.name == "match") {
        // console.log('MATCH: ', rule)
        if (rule.type == "exact") {
          find_data[rule.source] = rule.target
        } else if (rule.type == "if") {
          if (rule.target) {
            find_data[rule.source] = rule.target
          }
        }
      }
      if (rule.name == "skip") {
        // console.log('SKIP: ', rule)
        query_data["skip"] = parseInt(rule.target) || parseInt(rule.type)
      }
      if (rule.name == "limit") {
        // console.log('LIMIT: ', rule)
        query_data["limit"] = parseInt(rule.target) || parseInt(rule.type)
      }
      if (rule.name == "sort") {
        // console.log('SORT: ', rule)
        let field = rule.target ? rule.target : rule.type
        query_data["sort"] = { [field]: 1 }
      }
      if (rule.name == "order") {
        // console.log('ORDER: ', rule)
        let order = rule.target ? rule.target : rule.type
        for (let key in query_data["sort"]) {
          query_data["sort"][key] = order
        }
      }
    }

    // console.log({ projection: projection_data, find: find_data, query: query_data })
    // console.log(find_data)

    return { projection: projection_data, find: find_data, query: query_data }
  }
}
