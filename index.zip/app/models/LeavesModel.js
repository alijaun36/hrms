const mongoose = require('mongoose')

/**
 * @class LeavesModel
 * @description Creates a mongoose leaves model and defines its schema
 */
module.exports = class LeavesModel {
  /**
   * @constructor
   * @returns {mongoose.model} LeavesModel
   */
  constructor() {
    return mongoose.model('leaves', Schema, 'leaves')
  }
}

/**
 * Mongoose Schema
 */
const Schema = mongoose.Schema(
  {
    user_id: {type: mongoose.Schema.Types.ObjectId, ref: 'users', required: true },
    leave_reason: { type: String, default: null, required: true },
    from: { type: String, required: true },
    till: { type: String, required: true},
    leave_status: { type: String, enum : ["approved", "pending", "rejected"], required: true },
    leave_type : { type: String, enum: ['medical', 'annual', 'casual'], default: "casual" },
    approved_by: { type: String, default: null },
    created_by: { type: String, default: null },
    deleted_at: { type: Date, default: null },
    updated_by: { type: String, default: null },
    assign_to : { type: String, default: null }
  },
  {
    versionKey: false,
    timestamps: { createdAt: 'created_at', updatedAt: 'updated_at' }
  }
)
