const mongoose = require('mongoose')

/**
 * @class LeavesModel
 * @description Creates a mongoose leaves model and defines its schema
 */
module.exports = class LeavesModel {
  /**
   * @constructor
   * @returns {mongoose.model} LeavesModel
   */
  constructor() {
    return mongoose.model('leaves', Schema, 'leaves')
  }
}

/**
 * Mongoose Schema
 */
const Schema = mongoose.Schema(
  {
    user_id: {type: mongoose.Schema.Types.ObjectId, ref: 'users', required: true },
    leave_reason: { type: String, default: null, required: true },
    from: { type: String, required: true },
    till: { type: String, required: true},
    leave_status: { type: String, required: true },
    approved_by: { type: String, default: null, required: true },
    created_by: { type: String, default: null },
    deleted_at: { type: Date, default: null },
    updated_by: { type: String, default: null }
  },
  {
    versionKey: false,
    timestamps: { createdAt: 'created_at', updatedAt: 'updated_at' }
  }
)
