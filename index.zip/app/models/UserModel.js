const mongoose = require('mongoose')

/**
 * @class UserModel
 * @description Creates a mongoose user model and defines its schema
 */
module.exports = class UserModel {
  /**
   * @constructor
   * @returns {mongoose.model} UserModel
   */
  constructor() {
    return mongoose.model('users', Schema, 'users')
  }
}

/**
 * Mongoose Schema
 */
const Schema = mongoose.Schema(
  {
    first_name: { type: String, required: true },
    last_name: { type: String, required: true },
    gender : { type: String, default: 'Male'  },
    phone: { type: String, default: '' },
    email: { type: String, lowercase: true, required: true  },
    password: { type: String, default: '', required: true   },
    cnic : { type: Number },
    date_of_birth: { type: Date, default: null },
    photo: { type: String, default: ''  },
    address: { type: String, default: '' },
    designation: { type: String, default: '' },
    status: {
      type: String,
      enum: ['active', 'blocked'],
      default: "active"
    },
    type : { type : String , default : 'user', required: true },
    roles: [{ type: mongoose.Schema.Types.ObjectId, ref: 'roles'}],
    team: { type: mongoose.Schema.Types.ObjectId, ref: 'teams', required: true },
    created_by: { type: String, default: null },
    deleted_at: { type: Date, default: null },
    updated_by: { type: String },
  },
  {
    versionKey: false,
    timestamps: { createdAt: 'created_at', updatedAt: 'updated_at' },
  }
)
