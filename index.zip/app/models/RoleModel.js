const mongoose = require('mongoose')

/**
 * @class RoleModel
 * @description Creates a mongoose roles model and defines its schema
 */
module.exports = class RoleModel {
  /**
   * @constructor
   * @returns {mongoose.model} RoleModel
   */
  constructor() {
    return mongoose.model('roles', Schema, 'roles')
  }
}

/**
 * Mongoose Schema
 */
const Schema = mongoose.Schema(
  {
//  name: { type: String, default: '' },
    type: { type: String, enum: ['admin', 'hr', 'cto', 'manager', 'gm', 'lead'], default: "manager" },
    created_by: { type: String, default: null },
    deleted_at: { type: Date, default: null },
    updated_by: { type: String }
  },
  {
    versionKey: false,
    timestamps: { createdAt: 'created_at', updatedAt: 'updated_at' }
  }
)
