const mongoose = require('mongoose')

/**
 * @class AttendenceModel
 * @description Creates a mongoose attendence model and defines its schema
 */
module.exports = class AttendenceModel {
  /**
   * @constructor
   * @returns {mongoose.model} AttendenceModel
   */
  constructor() {
    return mongoose.model('attenedence', Schema, 'attenedence')
  }
}

/**
 * Mongoose Schema
 */
const Schema = mongoose.Schema(
  {
    user_id: {type: mongoose.Schema.Types.ObjectId, ref: 'users', required: true },
    sign_in : { type: Date, required: true },
    sign_out : { type: Date },
    created_by: { type: String, default: null },
    deleted_at: { type: Date, default: null },
    updated_by: { type: String }
  },
  {
    versionKey: false,
    timestamps: { createdAt: 'created_at', updatedAt: 'updated_at' }
  }
)
