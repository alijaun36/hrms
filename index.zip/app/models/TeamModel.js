const mongoose = require('mongoose')

/**
 * @class TeamModel
 * @description Creates a mongoose team model and defines its schema
 */
module.exports = class TeamModel {
  /**
   * @constructor
   * @returns {mongoose.model} TeamModel
   */
  constructor() {
    return mongoose.model('teams', Schema, 'teams')
  }
}

/**
 * Mongoose Schema
 */
const Schema = mongoose.Schema(
  {
    name: { type : String, required : true },
    created_by: { type: String, default: null },
    deleted_at: { type: Date, default: null },
    updated_by: { type: String }
  },
  {
    versionKey: false,
    timestamps: { createdAt: 'created_at', updatedAt: 'updated_at' }
  }
)
