const mongoose = require("mongoose")
const axios = require('axios');
/**
 * @class PaymentHelper
 * @description manage payment section
 */
module.exports = class PaymentHelper {
  constructor() {
    this.payment_model = resolveOnce('app.models.PaymentModel')
    this.ride_model = resolveOnce('app.models.RideModel')
    this.stipe_service = resolveOnce('app.services.StripeService')
    this.user_model = resolveOnce('app.models.UserModel')

  }

  /**
   * @method stripeCharge
   * @description pay from stripe and insert in payment model
   * @param {string} subject
   */
  async stripeCharge(ride, user, xero_invoice_id) {
    try {
      let already_payment = await this.payment_model.findOne({ 'ride_id': ride._id, 'status': 'paid' })

      if (already_payment) {
        return { error: false, message: "payment already done" }
      }
      if ((user.stripe_detail.cards).length == 0) {
        return { error: true, message: "No card found" }
      }
      let user_default_card = user.stripe_detail.cards
      user_default_card = user_default_card.slice(-1).pop()
      let total_amount = ride.ride_price + ride.gst + ride.booking_fee
      let result = await stripe.payWithCustomerId(user.stripe_detail.customer_id, total_amount, user_default_card.card_id)
      // let xero_payment = await this.createXeroPayment(user, total_amount, xero_invoice_id)
      let xero_payment_id = null
      // if (xero_payment.error == false) {
      //   xero_payment_id = xero_payment.payment_id
      // }
      let payment = await this.payment_model.create({
        user: user._id,
        xero_invoice: xero_invoice_id,
        xero_payment_id: xero_payment_id,
        amount: ride.ride_price,
        gst: ride.gst,
        booking_fee: ride.booking_fee,
        total_amount: total_amount,
        ride_id: ride._id,
        trip_id: ride.trip_id,
        status: 'paid',
        payment_id: result.id,
        gate_way: 'stripe'
      })

      let updated = await this.ride_model.findOneAndUpdate(
        { _id: ride._id },
        {
          $set: {
            'payment_id': payment._id
          },
        },
        { new: true, useFindAndModify: false }
      )

      return { error: false, message: "payment done successfully" }
    } catch (err) {
      logger.log({
        level: 'error',
        message: err,
      })
      return { error: true, message: "payment already done" }

    }
  }

  /**
   * @method validateXeroToken
   * @description Validate xero toekn and if expired than will update in user
   * @param {string} subject
   */
  async validateXeroToken(user) {
    let token = null
    if (user.xero_token == null) {
      token = await xero.createToken()
      await this.user_model.findOneAndUpdate({ _id: user._id }, { $set: { xero_token: JSON.stringify(token) } }, { new: true, useFindAndModify: false })
    } else {
      token = JSON.parse(user.xero_token)
      let stamp = new Date()
      if (token.expires_at < stamp.getTime() / 1000) {
        token = await xero.createToken()
        await this.user_model.findOneAndUpdate({ _id: user._id }, { $set: { xero_token: JSON.stringify(token) } }, { new: true, useFindAndModify: false })
      } else {
        await xero.setToken(token)
      }
    }
    return token
  }
  /**
    * @method createXeroInvoice
    * @description create xero invoice
    * @param {string} subject
    */

  async createXeroInvoice(request, ride_id) {
    // return { error: false, invoice_id: '000000' }

    try {
      let items = await this.makeRideLineItems(request)
      var ms = new Date().getTime() + 10 * 86400000
      var due_date = new Date(ms)

      await this.validateXeroToken(request.user)

      const invoice = {
        invoices: [
          {
            type: 'ACCREC',
            contact: {
              contactID: request.user.xero_contact_id
            },
            lineItems:items,
            // lineItems: [
            //   { "description": "acme Tires", "quantity": 2, "unitAmount": 20, "accountCode": "200" }
            // ], 
            "Date": new Date(),
            "DueDate": due_date,
            "Reference": ride_id,
            "Status": "AUTHORISED"
          }],
       
      }

      let id = await xero.createInvoices(invoice)
      return { error: false, invoice_id: id }

    } catch (err) {
      logger.log({
        level: "error",
        message: err,
      })
      return { error: true, message: "Xero Invoice not created" }
    }
  }

  async makeRideLineItems(request) {
    let items = []
    items.push({
      description: 'ride fee', quantity: 1, unitAmount: request.body.ride_price, accountCode: '201'
    })
    items.push({
      description: 'booking fee', quantity: 1, unitAmount: request.body.booking_fee, accountCode: '201'
    })
    items.push({
      description: 'GTS fee', quantity: 1, unitAmount: request.body.gst, accountCode: '201'
    })
    return items
  }

  async createXeroPayment(user, amount, invoice_id) {
    try {
      amount = parseFloat(amount)
      await this.validateXeroToken(user)
      let payments = { payments: [{ invoice: { invoiceID: invoice_id }, account: { code: '090' }, date: new Date(), amount: amount }] }
      let payment_detail = await xero.createPayments(payments)
      return { error: false, payment_id: payment_detail.payments[0].paymentID }
    } catch (err) {
      logger.log({
        level: "error",
        message: err,
      })
      return { error: true, message: "Payment Not Successfull !" }
    }
  }
}
