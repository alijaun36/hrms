const mongoose = require("mongoose")

/**
 * @class UploadHelper
 * @description Upload files helper
 */
module.exports = class UploadHelper {
  constructor() {}

  /**
   * @method handleImage
   * @description Handle upload of image file
   * @param {string} template
   * @param {string} subject
   * @param {string} email_address
   */
  async handleImage(request, name, path) {
    if (!request.files || request.files[name] === undefined)
      return { error: false, filename: null }
    let file = request.files[name]
    let extension = /[^.]+$/.exec(file.name)
    let filename_without_extension = file.name.replace("." + extension, "")
    let filename =
      name +
      "-" +
      filename_without_extension +
      "-" +
      mongoose.Types.ObjectId() +
      "." +
      extension
    filename = filename.replace(/ /g, "-")
    let new_filename = root_directory + path + filename
    let move_response = await file.mv(new_filename)
    if (move_response) return { error: true, message: "Unable to upload file" }

    // ^ @TODO add error logging
    return { error: false, filename: filename }
  }

  /**
   * @method handleImage
   * @description Handle upload of image file
   */
  async handleImageMultiple(request, name, path, arrayLength) {
    if (!request.files || request.files[name] === undefined)
      return { error: false, filename: null }
    if (!request.files[name].length) request.files[name] = [request.files[name]]

    var images_name_array = []
    for (let i = 0; i < request.files[name].length; i++) {
      let file = request.files[name][i]
      let extension = /[^.]+$/.exec(file.name)
      let filename_without_extension = file.name.replace("." + extension, "")
      let filename =
        name +
        "-" +
        filename_without_extension +
        "-" +
        mongoose.Types.ObjectId() +
        "." +
        extension
      filename = filename.replace(/ /g, "-")
      let new_filename = root_directory + path + filename
      let move_response = await file.mv(new_filename)
      // if (move_response) return { error: true, message: "Unable to upload file" };
      images_name_array.push(filename)
    }
    if (images_name_array.length == 1) {
      images_name_array = images_name_array[0]
    }
    // ^ @TODO add error logging
    return { error: false, filenames: images_name_array }
  }
}
