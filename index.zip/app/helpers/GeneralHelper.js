const mongoose = require("mongoose")
const axios = require('axios');
/**
 * @class GeneralHelper
 * @description manage generic functions
 */
module.exports = class GeneralHelper {
  constructor() {
    this.setting_model = resolveOnce('app.models.SettingModel')
  }

  /**
   * @method getSettingsKeys
   * @description get keys from settings table
   * @param {string} subject
   */
  async getSettingsKeys(meta_keys) {
    let settings = await this.setting_model.find({ 'meta_key': { $in: meta_keys } })
    if (settings == '') return ""
    const setting_data = {}
    settings.map(setting => setting_data[setting['meta_key']] = setting['meta_values'])
    return setting_data
  }
/**
   * @method calculateTripFare
   * @description return distance and fair between 2 points
   * @param {string} subject
   */

  async calculateTripFare(request) {
    let settings = await this.getSettingsKeys(['map_api_key','ride_per_km_fee','gst','booking_fee_pecentage'])
    if (settings == "") return ""
    let meta_key = settings.map_api_key
    let start_point = request.body.start_point
    let end_point = request.body.end_point
    var config = {
      method: 'get',
      url: `https://maps.googleapis.com/maps/api/distancematrix/json?origins=${start_point.latitude},${start_point.longitude}&destinations=${end_point.latitude},${end_point.longitude}&key=${meta_key}`,
    }
    let data = ""
    await axios(config)
      .then(function (response) {
        let response_data = response.data.rows[0].elements[0]
        let travel_fare = (response_data.distance.value / 1000) * parseFloat(settings.ride_per_km_fee)
        let gst = parseFloat(settings.gst)/100 * parseFloat(travel_fare) 
        let booking_fee = parseFloat(settings.booking_fee_pecentage)/100 * parseFloat(travel_fare)
        data = { 'distance': response_data.distance.value, 'duration': response_data.duration.value,'fare': travel_fare,'gst':gst,'booking_fee': booking_fee }
      })
      .catch(function (err) {
        logger.log({
          level: 'error',
          message: err,
        })
      })
    return { data }
  }

}
