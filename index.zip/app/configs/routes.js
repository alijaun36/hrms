/**
 * Route configurations
 */
 module.exports = [
     'routes.api',
     'routes.xero_test_routes',
 ]