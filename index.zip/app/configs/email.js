/**
 * Email configurations
 */
module.exports = {
  email_client: getEnv('EMAIL_CLIENT', 'smtp'),
  email_host: getEnv('EMAIL_HOST', 'smtp.gmail.com'),
  email_port: getEnv('EMAIL_PORT', 465),
  email_username: getEnv('EMAIL_USERNAME', 'amelia@roadie.co.nz'),
  email_password: getEnv('EMAIL_PASSWORD', 'rossendale4975'),
  email_sender: getEnv('EMAIL_SENDER', 'no-reply@roadie.co.nz'),
  email_sender_name: getEnv('EMAIL_SENDER_NAME', 'Roadie'),

  // email_client: getEnv("EMAIL_CLIENT", "smtp"),
  // email_host: getEnv("EMAIL_HOST", "smtp.mailtrap.io"),
  // email_port: getEnv("EMAIL_PORT", 2525),
  // email_username: getEnv("EMAIL_USERNAME", "337a21f8f20eec"),
  // email_password: getEnv("EMAIL_PASSWORD", "c45b88673268a7"),
  // email_sender: getEnv("EMAIL_SENDER", "no-reply@roadie.com"),
  // email_sender_name: getEnv("EMAIL_SENDER_NAME", "roadie"),
}
