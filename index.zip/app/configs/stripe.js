/**
 * Stripe configurations
 */
module.exports = {
    'stripe_key': getEnv('STRIPE_KEY', 'sk_test_4MfKSTHtgAS2FmpB5KqYd0em'),
    'stripe_currency': getEnv('STRIPE_CURRENCY', 'usd')
}