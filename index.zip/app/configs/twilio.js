/**
 * Twilio configurations
 */
module.exports = {
    'acountSid': getEnv('TWILIO_ACCOUNTS_ID', 'ACb23cbcd7577883ab8faab0c98626fd28'),
    'authToken': getEnv('TWILIO_AUTH_TOKEN', '9f9678d62a59a1125fceda710a50d9fc'),
}