/**
 * Services configuration
 */
module.exports = {
  logger: getEnv("SERVICE_LOGGER", true),
  cron: getEnv("SERVICE_CRON", true),
  auth: getEnv("SERVICE_AUTH", true),
  mongo: getEnv("SERVICE_MONGO", true),
  mail: getEnv("SERVICE_MAIL", true),
  permissions: getEnv("SERVICE_PERMISSIONS", true),
  stripe: getEnv("SERVICE_STRIPE", true),
  xero: getEnv("SERVICE_XERO", true),
  twilio: getEnv("SERVICE_TWILIO", true),
  socket: getEnv("SERVICE_SOCKET", true)

}
