/**
 * Xero configurations
 */
module.exports = {
    'client_id': getEnv('XERO_CLIENT_ID', 'F6A45140F70948B5BF1FCAC5D72090B8'),
    'client_secret': getEnv('XERO_CLIENT_SECRET', '_RfSybFf4bYMlMmYXlDzytlGhdN8BnCKP6pKlhvX8u3SBf5a'),
    'scopes': getEnv('XERO_SCOPES', 'openid profile email accounting.transactions projects offline_access'),
    'timeout': getEnv('XERO_TIMEOUT', 5000), 
    'auth_url': getEnv('XERO_AUTH_URL', 'https://identity.xero.com/connect/token'), 
    'api_url': getEnv('XERO_API_URL', 'https://api.xero.com/api.xro/2.0'), 
}