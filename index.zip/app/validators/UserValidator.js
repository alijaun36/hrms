var ObjectId = require("mongoose").Types.ObjectId

/**
 * @class UserValidator
 * @description Validator for User controller
 */
module.exports = class UserValidator {
  constructor() {}

  /**
   * @method validateId
   * @param {object} request
   * @param {object} response
   * @returns {object} response
   */
  async validateId(request, response) {
    let errors = []

    if (request.params.id === undefined) errors.push("Id param is required")
    if (request.params.id.length != 24)
      errors.push("Id param should be 24 characters")
    if (!ObjectId.isValid(request.params.id)) errors.push("Invalid mongo id")

    return { error: errors.length > 0 ? true : false, errors: errors }
  }

  /**
   * @method storeAction
   * @param {object} request
   * @param {object} response
   * @returns {object} response
   */
  async storeAction(request, response, user_model) {
    let errors = []
    let user = await user_model.findOne({ email: request.body.email }).lean()

    if (user) {
      if (user.email === request.body.email)
        errors.push("Email has already been taken")
    }
    let validator_errors = request.validate(request.body, [
      {
        name: "name",
        required: true,
        type: "string",
      },
      {
        name: "username",
        required: true,
        type: "string",
      },
      {
        name: "email",
        required: true,
        type: "string",
      },
      {
        name: "phone",
        default: "",
        type: "string",
      },

      {
        name: "password",
        type: "string",
      },
    ])
    errors = errors.concat(validator_errors)
    return { error: errors.length > 0 ? true : false, errors: errors }
  }

  /**
   * @method updateAction
   * @param {object} request
   * @param {object} response
   * @returns {object} response
   */
  async updateAction(request, response, user_model) {
    let errors = []

    if (request.params.id === undefined) errors.push("Id param is required")
    if (request.params.id.length != 24)
      errors.push("Id param should be 24 characters")
    if (!ObjectId.isValid(request.params.id)) errors.push("Invalid mongo id")
    if (errors.length > 0) {
      return { error: true, errors: errors }
    }
    let user = await user_model
      .findOne({ _id: { $ne: request.params.id }, contact: request.body.email })
      .lean()
    if (user) {
      if (user.email === request.body.email)
        return response
          .status(400)
          .json({ message: "Email has already been taken" })
    }
    errors = request.validate(request.body, [
      {
        name: "firstname",
        type: "string",
      },
      {
        name: "lastname",
        type: "string",
      },
      {
        name: "phone",
        type: "string",
      },
    ])
    return { error: errors.length > 0 ? true : false, errors: errors }
  }

  /**
   * @method validateUserIdWithProjection
   * @param {object} request
   * @param {object} response
   * @returns {object} response
   */
  async validateUserIdWithProjection(request, response) {
    let errors = []
    if (request.params.id === undefined) errors.push("Id param is required")
    if (request.params.id.length != 24)
      errors.push("Id param should be 24 characters long")
    if (!ObjectId.isValid(request.params.id)) errors.push("Invalid mongo id")

    let projection = {
      reset_password_token: 0,
      reset_password_created_at: 0,
      password: 0,
    }
    return {
      error: errors.length > 0 ? true : false,
      errors: errors,
      projection: projection,
    }
  }

  /**
   * @method indexAction
   * @param {object} request
   * @param {object} response
   * @returns {object} response
   */
  async indexAction(request, response) {
    let query_params = {
      skip: parseInt(request.query.skip) || 0,
      limit: parseInt(request.query.limit) || 10,
      sort: {},
    }
    let order = request.query.order || "asc"
    let field = request.query.sort || "firstname"
    let direction = order == "asc" ? 1 : -1
    query_params.sort[field] = direction

    let search_params = {}

    if (request.query.search) {
      search_params["$or"] = []
      search_params["$or"] = search_params["$or"].concat([
        { email: new RegExp(request.query.search + ".*", "i") },
        { firstname: new RegExp(request.query.search + ".*", "i") },
        { lastname: new RegExp(request.query.search + ".*", "i") },
        { phone: new RegExp(request.query.search + ".*", "i") },
      ])
    }

    if (request.query.date) {
      let date = new Date(request.query.date)
      search_params["created_at"] = {
        $gte: new Date(date.setHours(0, 0, 0, 0)),
        $lte: new Date(date.setHours(23, 59, 59, 999)),
      }
    }

    search_params["type"] = "user"
    search_params["deleted_at"] = null
    let projection = { password: 0 }

    return {
      query: query_params,
      search: search_params,
      projection: projection,
    }
  }

  /**
   * @method doesImageExist
   * @param {object} request
   * @param {object} response
   * @returns {object} response
   */
  async doesImageExist(request, response) {
    let errors = []

    if (request.params.filename === undefined)
      errors.push("filename param is required")
    let file_path =
      root_directory + "/public/user_images/" + request.params.filename
    if (!fs.existsSync(file_path))
      errors.push("provided filename does not exist")

    return { error: errors.length > 0 ? true : false, errors: errors }
  }
}
