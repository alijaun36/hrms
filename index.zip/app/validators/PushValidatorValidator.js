var ObjectId = require('mongoose').Types.ObjectId

/**
 * @class PushValidatorValidator
 * @description Validator for Job controller
 */
module.exports = class PushValidatorValidator {
  constructor() {}

  /**
   * @method validateId
   * @param {object} request
   * @param {object} response
   * @returns {object} response
   */
  async validateId(request, response) {
    let errors = []

    if (request.params.id === undefined) errors.push('Id param is required')
    if (request.params.id.length != 24)
      errors.push('Id param should be 24 characters')
    if (!ObjectId.isValid(request.params.id)) errors.push('Invalid mongo id')

    return { error: errors.length > 0 ? true : false, errors: errors }
  }

  /**
   * @method storeAction
   * @param {object} request
   * @param {object} response
   * @returns {object} response
   */
  async storeAction(request, response) {
    let errors = []

    let validator_errors = request.validate(request.body, [
      {
        name: 'title',
        required: true,
        type: 'string'
      },
      {
        name: 'message',
        required: true,
        type: 'string'
      }
    ])
    errors = errors.concat(validator_errors)
    return { error: errors.length > 0 ? true : false, errors: errors }
  }

  /**
   * @method updateAction
   * @param {object} request
   * @param {object} response
   * @returns {object} response
   */
  async updateAction(request, response) {
    let errors = []

    if (request.params.id === undefined) errors.push('Id param is required')
    if (request.params.id.length != 24)
      errors.push('Id param should be 24 characters')
    if (!ObjectId.isValid(request.params.id)) errors.push('Invalid mongo id')
    if (errors.length > 0) {
      return { error: true, errors: errors }
    }

    errors = request.validate(request.body, [
      {
        name: 'title',
        type: 'string'
      },
      {
        name: 'message',
        type: 'string'
      }
    ])
    return { error: errors.length > 0 ? true : false, errors: errors }
  }

  /**
   * @method indexAction
   * @param {object} request
   * @param {object} response
   * @returns {object} response
   */
  async indexAction(request, response) {
    let query_params = {
      skip: parseInt(request.query.skip) || 0,
      limit: parseInt(request.query.limit) || 25,
      sort: {}
    }
    query_params.sort['_id'] = 'desc'
    return {
      query: query_params
    }
  }
}
