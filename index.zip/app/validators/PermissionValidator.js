var ObjectId = require("mongoose").Types.ObjectId

/**
 * @class PermissionValidator
 * @description Validator for Permission controller
 */
module.exports = class PermissionValidator {
  constructor() {}

  /**
   * @method validateId
   * @param {object} request
   * @param {object} response
   * @returns {object} response
   */
  async validateId(request, response) {
    let errors = []

    if (request.params.id === undefined) errors.push("Id param is required")
    if (request.params.id.length != 24)
      errors.push("Id param should be 24 characters")
    if (!ObjectId.isValid(request.params.id)) errors.push("Invalid mongo id")

    return { error: errors.length > 0 ? true : false, errors: errors }
  }

  /**
   * @method storeAction
   * @param {object} request
   * @param {object} response
   * @returns {object} response
   */
  async storeAction(request, response, permission_model) {
    let errors = []

    let validator_errors = request.validate(request.body, [
      {
        name: "name",
        required: true,
        type: "string",
      },
    ])
    errors = errors.concat(validator_errors)
    return { error: errors.length > 0 ? true : false, errors: errors }
  }

  /**
   * @method updateAction
   * @param {object} request
   * @param {object} response
   * @returns {object} response
   */
  async updateAction(request, response, permission_model) {
    let errors = []

    if (request.params.id === undefined) errors.push("Id param is required")
    if (request.params.id.length != 24)
      errors.push("Id param should be 24 characters")
    if (!ObjectId.isValid(request.params.id)) errors.push("Invalid mongo id")
    if (errors.length > 0) {
      return { error: true, errors: errors }
    }
    errors = request.validate(request.body, [
      {
        name: "name",
        type: "string",
      },
    ])
    return { error: errors.length > 0 ? true : false, errors: errors }
  }

  /**
   * @method indexAction
   * @param {object} request
   * @param {object} response
   * @returns {object} response
   */
  async indexAction(request, response) {
    let query_params = {
      skip: parseInt(request.query.skip) || 0,
      limit: parseInt(request.query.limit) || 10,
      sort: {},
    }
    let order = request.query.order || "asc"
    let field = request.query.sort || "name"
    let direction = order == "asc" ? 1 : -1
    query_params.sort[field] = direction

    let search_params = {}

    if (request.query.search) {
      search_params["$or"] = []
      search_params["$or"] = search_params["$or"].concat([
        { name: new RegExp(request.query.search + ".*", "i") },
      ])
    }

    search_params["deleted_at"] = null

    return {
      query: query_params,
      search: search_params,
    }
  }
}
