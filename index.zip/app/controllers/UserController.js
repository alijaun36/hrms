const mongoose = require("mongoose")

/**
 * @class UserController
 * @description Handles all user related CRUD operations
 */
module.exports = class UserController {
  /**
   * @constructor
   * @description Handles autoloaded dependencies
   */
  constructor(app) {
    this.user_model = app.get("UserModel")
    this.role_model = app.get("RoleModel")
  }

  // /**
  //  * @method index
  //  * @description Returns list of user
  //  * @param {object} request
  //  * @param {object} response
  //  */
  // async index(request, response) {
  //   try {
  //     /** Permission validation */
  //     let allowed = permissions.can("users.getAll")
  //     if (!allowed)
  //       return response
  //         .status(400)
  //         .json({ message: "Validation error", errors: "Permission Denied" })

  //     /** Request validation */
  //     let filters = await request.filter({
  //       search: "likes:first_name,last_name,email,gender,phone,",
  //       skip: "skip:0",
  //       limit: "limit",
  //       sort: "sort:_id",
  //       order: "order",
  //     })

  //     filters.find["type"] = "user"

  //     let user_data = []
  //     let users = await this.user_model
  //       .find(filters.find)
  //       .skip(filters.query.skip)
  //       .limit(filters.query.limit)
  //       .sort(filters.query.sort)
  //       .select(filters.projection)
  //       .lean()

  //     // let vehicles = await this.vehicle_model.find({ driver_id: user })

  //     let total = await this.user_model.countDocuments(filters.find)

  //     for (let i = 0; i < users.length; i++) {
  //       let driver_vehicles = await this.driver_vehicle.findOne({
  //         driver_id: users[i]._id,
  //         default: true,
  //       })
  //       let driver_details = {
  //         ...users[i],
  //         ...{ driver_vehicles: driver_vehicles },
  //       }
  //       user_data.push(driver_details)
  //     }

  //     /** Response */
  //     return response.status(200).json({
  //       pagination: {
  //         skip: filters.query.skip,
  //         limit: filters.query.limit,
  //         total,
  //       },
  //       user: user_data,
  //     })
  //   } catch (err) {
  //     logger.log({
  //       level: "error",
  //       message: err,
  //     })
  //     return response.status(400).send({ message: "Something went wrong" })
  //   }
  // }




/**
   * @method index
   * @description Returns list of users
   * @param {object} request
   * @param {object} response
   * @return {image} response
   */
async index(request, response) {
  try {
    /** Permission validation */
    // let allowed = permissions.can("roles.getAll")
    // if (!allowed) return response.status(400).json({ message: 'Validation error', errors: "Permission Denied" })

    /** Request validation */
    let filters = await request.filter({
      search: "LIKE:name",
      skip: "skip:0",
      limit: "limit",
      sort: "sort:_id",
      order: "order:1",
    })



    let name = []

    let user = await this.user_model
      .find(filters.find)
      .populate(["team", "roles"])
      .skip(filters.query.skip)
      .limit(filters.query.limit)
      .sort(filters.query.sort)
      .select(filters.projection)
      .lean()

    // user.forEach(a =>{
    //   console.log(a,'a')
    // })


    if(request.query.team !== undefined && request.query.team != ''){
      filters.find["team"] = request.query.team
    }

    console.log('filters',filters)

   

    // if(request.user.type === "admin"){
    //   filters.find["type"] = "admin"
    // }

// if(request.query.type !== undefined && request.query.type != ''){
//   filters.find["type"] = request.query.type
// }
// console.log('filters',filters)


    let total = await this.user_model.countDocuments(filters.find)

    /** Response */
    return response.status(200).json({
      pagination: {
        skip: filters.query.skip,
        limit: filters.query.limit,
        total,
      },
      user,
    })
  } catch (err) {
    logger.log({
      level: "error",
      message: err,
    })
    console.log(err)
    return response.status(400).send({ message: "Something went wrong" })
  }
}








  // /**
  //  * @method store
  //  * @description Create new user
  //  * @param {object} request
  //  * @param {object} response
  //  */
  // async store(request, response) {
  //   try {
  //     /** Request validation */
  //     if (request.body.google_signup) {
  //       var validation = await request.validate({
  //         first_name: "first_name|required",
  //         last_name: "last_name|required",
  //         email: "email|required",
  //         google_token: "required",
  //         gender: "required",
  //         // date_of_birth: 'required',
  //       })
  //     } else {
  //       var validation = await request.validate({
  //         first_name: "first_name|required",
  //         last_name: "last_name|required",
  //         email: "email|required|unique:UserModel.email",
  //         password: "string|required",
  //         gender: "required",
  //         // date_of_birth: 'required',
  //       })
  //     }
  //     if (validation && validation.length > 0)
  //       return response.status(400).json({ message: "Validation error", errors: validation })

  //     if (request.body.type && request.body.type == "admin") {
  //       request.body.type = "admin"
  //       if (!request.body.roles) {
  //         let role = await this.role_model.findOne({ name: "admin" })
  //         request.body.roles = role._id
  //       }
  //     } else {
  //       request.body.type = "user"
  //       if (request.body.is_passenger) {
  //         let role = await this.role_model.findOne({ name: "passenger" })
  //         request.body.roles = role._id
  //       } else if (request.body.is_driver) {
  //         let role = await this.role_model.findOne({ name: "driver" })
  //         request.body.roles = role._id
  //       }
  //     }

  //     let image_uploader = null
  //     if (request.files) {
  //       image_uploader = await this.upload_helper.handleImage(
  //         request,
  //         "photo",
  //         "/public/user_images/"
  //       )
  //     }
  //     if (image_uploader) {
  //       if (image_uploader.error)
  //         return response.status(400).json({ message: "Failed to upload image" })
  //       else request.body.photo = image_uploader.filename
  //     }
  //     let user_found = false
  //     if (request.body.google_signup) {
  //       user_found = await this.user_model.findOne({
  //         email: request.body.email,
  //       })
  //     }
  //     if (request.body.password) {
  //       request.body.password = auth.hashPassword(request.body.password, Config.app("salt"))
  //     }
  //     let user = ""

  //     if (user_found) {
  //       user = await this.user_model.findOneAndUpdate(
  //         { _id: user_found._id },
  //         {
  //           $set: request.body,
  //         },
  //         { new: true, useFindAndModify: false }
  //       )
  //     } else {
  //       user = await this.user_model.create(request.body)
  //     }
  //     if (!user.xero_contact_id || user.xero_contact_id == null) {
  //       await this.payment_helper.validateXeroToken(user)
  //       let user_xero_contact = await xero.createContact(user)
  //       if (user_xero_contact.contacts[0].contactID) {
  //         request.body.xero_contact_id = user_xero_contact.contacts[0].contactID
  //         await this.user_model.findOneAndUpdate(
  //           { _id: user._id },
  //           {
  //             $set: { xero_contact_id: request.body.xero_contact_id },
  //           },
  //           { new: true, useFindAndModify: false }
  //         )
  //       }
  //     }

  //     let template = await view().render("templates.signup-welcome", {
  //       base_url: Config.app("base_url"),
  //       name: `${request.body.first_name} ${request.body.last_name}`,
  //       app: Config.app("app_name"),
  //     })

  //     await mail.send(template, "Welcome to Roadie!", request.body.email)

  //     /**Notification */
  //     if (request.body.is_driver === true) {
  //       let admin = await this.user_model.findOne({ type: "admin" })
  //       if (admin)
  //         await this.notification_model.create({
  //           title: "Driver Verification",
  //           message:
  //             request.body.first_name + " " + request.body.last_name + " " + "Needed Verification",
  //           to_user: admin._id,
  //           url: "/user-edit/" + request.params._id,
  //         })
  //       console.log("ok")
  //     }

  //     return response.status(200).json({
  //       message: "User created successfully",
  //       user: user,
  //       token: auth.generateToken(user._id.toString()),
  //     })
  //   } catch (err) {
  //     logger.log({
  //       level: "error",
  //       message: err,
  //     })
  //     return response.status(400).send({ message: "Something went wrong" })
  //   }
  // }





/**
   * @method store
   * @description Create new user
   * @param {object} request
   * @param {object} response
   * @return {object} response
   */
  async store(request, response) {
    try {
      /** Permission validation */
      // let allowed = permissions.can("roles.create")
      // if (!allowed) return response.status(400).json({ message: 'Validation error', errors: "Permission Denied" })

      /** Request validation */
      let validation = await request.validate({
        first_name: "required|string",
        last_name: "required|string",
        email: "required|string",
        password: "required|string",
        team: "string|required",
      })
      if (validation && validation.length)
        return response
          .status(400)
          .json({ message: "Validation error", errors: validation })

      if (request.body.password) {
        request.body.password = auth.hashPassword(request.body.password, Config.app("salt"))
      }


      /** Response */
      let user = await this.user_model.create(request.body)
      return response.status(200).json({
        message: "team created successfully",
        user: user,
      })
    } catch (err) {
      logger.log({
        level: "error",
        message: err,
      })
      return response.status(400).send({ message: "Something went wrong" })
    }
  }






  // /**
  //  * @method show
  //  * @description Returns single user based on provided id
  //  * @param {object} request
  //  * @param {object} response
  //  * @return {object} response
  //  */
  // async show(request, response) {
  //   try {
  //     /** Permission validation */
  //     // let allowed = permissions.can("users.getOne")
  //     // if (!allowed)
  //     //   return response
  //     //     .status(400)
  //     //     .json({ message: "Validation error", errors: "Permission Denied" })

  //     /** Request validation */
  //     let result = await request.validate({
  //       _id: "mongoId|required",
  //     })
  //     if (result && result.length > 0)
  //       return response.status(400).json({ message: "Validation error", errors: result })
  //     let user = await this.user_model.findOne({ _id: request.params._id }).populate({
  //       path: "roles",
  //     })
  //     if (!user) return response.status(400).json({ message: "User does not exist" })

  //     /** Response */
  //     return response.status(200).json({ user })
  //   } catch (err) {
  //     logger.log({
  //       level: "error",
  //       message: err,
  //     })
  //     return response.status(400).send({ message: "Something went wrong" })
  //   }
  // }


  /**
   * @method show
   * @description Returns single leave based on provided id
   * @param {object} request
   * @param {object} response
   * @return {object} response
   */
  async show(request, response) {
    try {
      /** Permission validation */
      // let allowed = permissions.can("roles.getOne")
      // if (!allowed) return response.status(400).json({ message: 'Validation error', errors: "Permission Denied" })

      /** Request validation */
      let result = await request.validate({
        _id: "required|mongoId",
      })
      if (result && result.length)
        return response
          .status(400)
          .json({ message: "Validation error", errors: result })
      let user = await this.user_model.findOne({ _id: request.params._id })
      if (!user)
        return response.status(400).json({ message: "User does not exist" })

      /** Response */
      return response.status(200).json(user)
    } catch (err) {
      logger.log({
        level: "error",
        message: err,
      })
      return response.status(400).send({ message: "Something went wrong" })
    }
  }





  // /**
  //  * @method update
  //  * @description Update user
  //  * @param {object} request
  //  * @param {object} response
  //  * @return {object} response
  //  */
  // async update(request, response) {
  //   try {
  //     /** Permission validation */
  //     let allowed = permissions.can("users.update")
  //     if (!allowed)
  //       return response
  //         .status(400)
  //         .json({ message: "Validation error", errors: "Permission Denied" })

  //     /** Request validation */
  //     // let validation = await this.user_validator.updateAction(
  //     //   request,
  //     //   response,
  //     //   this.user_model
  //     // )
  //     let validation = await request.validate({
  //       first_name: "string",
  //       last_name: "string",
  //       _id: "required|mongoId",
  //     })
  //     if (typeof request.body.roles === "string" || typeof request.body.roles === String) {
  //       request.body.roles = request.body.roles.split(",")
  //     }
  //     if (validation && validation.length > 0)
  //       return response.status(400).json({ message: "Validation error", errors: validation })

  //     request.body.updated_by = request.user.email
  //     /** Image Update */

  //     let image_uploader = null
  //     if (request.files) {
  //       image_uploader = await this.upload_helper.handleImage(
  //         request,
  //         "photo",
  //         "/public/user_images/"
  //       )
  //     }
  //     let user = await this.user_model.findOne({ _id: request.params._id })
  //     if (image_uploader) {
  //       if (user.photo && fs.existsSync(root_directory + "/public/user_images/" + user.photo)) {
  //         fs.unlinkSync(root_directory + "/public/user_images/" + user.photo)
  //       }
  //       request.body.photo = image_uploader.filename
  //     } else {
  //       request.body.photo = user.photo
  //     }

  //     let updated = await this.user_model.findOneAndUpdate(
  //       { _id: request.params._id },
  //       {
  //         $set: request.body,
  //       },
  //       { new: true, useFindAndModify: false }
  //     )
  //     updated = await this.user_model.findOne({ _id: request.user._id }).populate({
  //       path: "roles",
  //     })

  //     /** Response */
  //     return response.status(200).json({ message: "User updated successfully", user: updated })
  //   } catch (err) {
  //     logger.log({
  //       level: "error",
  //       message: err,
  //     })
  //     return response.status(400).send({ message: "Something went wrong" })
  //   }
  // }






    /**
   * @method update
   * @description Update user
   * @param {object} request
   * @param {object} response
   * @return {object} response
   */
    async update(request, response) {
      try {
        /** Permission validation */
  
        // let allowed = permissions.can("roles.update")
        // if (!allowed) return response.status(400).json({ message: 'Validation error', errors: "Permission Denied" })
  
        /** Request validation */
        let validation = await request.validate({
          _id: "required|mongoId",
          last_name: "required|string",
        })
        if (validation && validation.length)
          return response
            .status(400)
            .json({ message: "Validation error", errors: validation })
  
      //  request.body.updated_by = request.user.email
  
        let updated = await this.user_model.findOneAndUpdate(
          { _id: request.params._id },
          {
            $set: request.body,
          },
          { new: true, useFindAndModify: false }
        )
  
        /** Response */
        return response
          .status(200)
          .json({ message: "Team updated successfully", user: updated })
      } catch (err) {
        logger.log({
          level: "error",
          message: err,
        })
        return response.status(400).send({ message: "Something went wrong" })
      }
    }






      /**
   * @method destroy
   * @description delete user
   * @param {object} request
   * @param {object} response
   * @return {object} response
   */
  async destroy(request, response) {
    try {
      /** Permission validation */

      // let allowed = permissions.can("roles.delete")
      // if (!allowed) return response.status(400).json({ message: 'Validation error', errors: "Permission Denied" })

      /** Request validation */
      let result = await request.validate({
        _id: "required|mongoId",
      })
      if (result && result.length)
        return response
          .status(400)
          .json({ message: "Validation error", errors: result })
      let user = await this.user_model.findOne({ _id: request.params._id })

      if (!user) {
        return response.status(400).json({ message: "user does not exists" })
      }
      let users = await this.user_model.find({
        user: user._id,
      })
      for (let i = 0;i < users.length;i++) {
        if (users[i].user && users[i].user.length)
          users[i].user = users[i].user.filter(function (value) {
            return value != request.params.id
          })
        users[i].save()
      }
      user.remove()

      /** Response */
      return response.status(200).json({ message: "user deleted successfully" })
    } catch (err) {
      logger.log({
        level: "error",
        message: err,
      })
      return response.status(400).send({ message: "Something went wrong" })
    }
  }






  // /**
  //  * @method profileImage
  //  * @description Returns a user profile image
  //  * @param {object} request
  //  * @param {object} response
  //  * @return {image} response
  //  */
  // async profileImage(request, response) {
  //   try {
  //     /** Permission validation */
  //     // let allowed = permissions.can('users.getProfileImage')
  //     // if (!allowed)
  //     //   return response
  //     //     .status(400)
  //     //     .json({ message: 'Validation error', errors: 'Permission Denied' })

  //     if (request.params.filename === undefined)
  //       return response.status(400).json({
  //         message: "Validation error",
  //         errors: "filename param is required",
  //       })
  //     let file_path = root_directory + "/public/user_images/" + request.params.filename
  //     if (!fs.existsSync(file_path))
  //       return response.status(400).json({
  //         message: "Validation error",
  //         errors: "provided filename does not exist",
  //       })

  //     return response.sendFile(file_path)
  //   } catch (err) {
  //     logger.log({
  //       level: "error",
  //       message: err,
  //     })
  //     return response.status(400).send({ message: "Something went wrong" })
  //   }
  // }

  // /**
  //  * @method resetPassword
  //  * @description Returns a user profile image
  //  * @param {object} request
  //  * @param {object} response
  //  * @return {image} response
  //  */
  // async resetPassword(request, response) {
  //   try {
  //     let validation = await request.validate({
  //       _id: "required|mongoId",
  //       old_password: "required|string",
  //       new_password: "required|string",
  //       current_password: "required|string",
  //     })
  //     if (validation && validation.length > 0)
  //       return response.status(400).json({ message: "Validation error", errors: validation })
  //     let user = await this.user_model.findOne({ _id: request.params._id })
  //     if (!user) return response.status(400).json({ errors: ["User Not Found"] })
  //     request.body.old_password = auth.hashPassword(request.body.old_password, Config.app("salt"))
  //     if (user.password !== request.body.old_password) {
  //       return response.status(400).json({ errors: "Old Password is incorrect" })
  //     }
  //     if (request.body.new_password !== request.body.current_password)
  //       return response.status(400).json({ errors: "New and Confirm New password does not match" })
  //     request.body.new_password = auth.hashPassword(request.body.new_password, Config.app("salt"))
  //     user.password = request.body.new_password

  //     user.save()
  //     return response.status(200).json({ message: "Password Updated Successfully" })
  //   } catch {}
  // }
}
