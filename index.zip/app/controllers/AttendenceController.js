const mongoose = require("mongoose")
/**
 * @class AttendenceController
 * @description Handles all attendence related CRUD operations
 */
module.exports = class AttendenceController {
  /**
   * @constructor
   * @description Handles autoloaded dependencies
   */
  constructor(app) {
    this.attendence_model = app.get("AttendenceModel") // Role
    this.user_model = app.get("UserModel")
  }

  /**
   * @method index
   * @description Returns list of attendence
   * @param {object} request
   * @param {object} response
   * @return {image} response
   */
  async index(request, response) {
    try {
      /** Permission validation */
      // let allowed = permissions.can("roles.getAll")
      // if (!allowed) return response.status(400).json({ message: 'Validation error', errors: "Permission Denied" })

      /** Request validation */
      let filters = await request.filter({
        search: "LIKE:name",
        skip: "skip:0",
        limit: "limit",
        sort: "sort:_id",
        order: "order:1",
      })
      let attendence = await this.attendence_model
        .find(filters.find)
        // .populate("permissions")
        .skip(filters.query.skip)
        .limit(filters.query.limit)
        .sort(filters.query.sort)
        .select(filters.projection)
        .lean()
      let total = await this.attendence_model.countDocuments(filters.find)

      /** Response */
      return response.status(200).json({
        pagination: {
          skip: filters.query.skip,
          limit: filters.query.limit,
          total,
        },
        attendence,
      })
    } catch (err) {
      logger.log({
        level: "error",
        message: err,
      })
      console.log(err)
      return response.status(400).send({ message: "Something went wrong" })
    }
  }



  /**
   * @method store
   * @description Create new attendence
   * @param {object} request
   * @param {object} response
   * @return {object} response
   */
 // async store(request, response) {
 //   try {
      /** Permission validation */
      // let allowed = permissions.can("roles.create")
      // if (!allowed) return response.status(400).json({ message: 'Validation error', errors: "Permission Denied" })

      /** Request validation */
  //     let validation = await request.validate({
  //       user_id : "required|mongoId",
  //       sign_in : "required|string"
  //     })
  //     if (validation && validation.length)
  //       return response
  //         .status(400)
  //         .json({ message: "Validation error", errors: validation })


  //     let attendence = await this.attendence_model.create(request.body)
  //     return response.status(200).json({
  //       message: "Attendence created successfully",
  //       attendence: attendence,
  //     })
  //   } catch (err) {
  //     logger.log({
  //       level: "error",
  //       message: err,
  //     })
  //     return response.status(400).send({ message: "Something went wrong" })
  //   }
  // }






  /**
   * @method store
   * @description Create new attendence
   * @param {object} request
   * @param {object} response
   * @return {object} response
   */
  async store(request, response) {
    try {
      /** Permission validation */
      // let allowed = permissions.can("roles.create")
      // if (!allowed) return response.status(400).json({ message: 'Validation error', errors: "Permission Denied" })

      /** Request validation */
      let validation = await request.validate({
        user_id : "required|mongoId",
        sign_in : "required|string"
      })
      if (validation && validation.length)
        return response
          .status(400)
          .json({ message: "Validation error", errors: validation })

      
      /** Response */
      let attendence = await this.attendence_model.create({
        user_id : request.body.user_id,
        date : request.body.date,
        stay_time : [ {
          sign_in : request.body.sign_in,
          sign_out : null
        }          
        ] 
      })
      // console.log(attendence) 
      return response.status(200).json({
        message: "Attendence created successfully",
        attendence: attendence,
      })
    } catch (err) {
      logger.log({
        level: "error",
        message: err,
      })
      return response.status(400).send({ message: "Something went wrong" })
    }
  }







  /**
   * @method show
   * @description Returns single Attendence based on provided id
   * @param {object} request
   * @param {object} response
   * @return {object} response
   */
  async show(request, response) {
    try {
      /** Permission validation */
      // let allowed = permissions.can("roles.getOne")
      // if (!allowed) return response.status(400).json({ message: 'Validation error', errors: "Permission Denied" })

      /** Request validation */
      let result = await request.validate({
        _id: "required|mongoId",
      })
      if (result && result.length)
        return response
          .status(400)
          .json({ message: "Validation error", errors: result })
      let team = await this.attendence_model.findOne({ _id: request.params._id })
      if (!team)
        return response.status(400).json({ message: "Attendence does not exist" })

      /** Response */
      return response.status(200).json(team)
    } catch (err) {
      logger.log({
        level: "error",
        message: err,
      })
      return response.status(400).send({ message: "Something went wrong" })
    }
  }







  /**
   * @method update
   * @description Update attendence
   * @param {object} request
   * @param {object} response
   * @return {object} response
   */
  async update(request, response) {
    try {
      /** Permission validation */

      // let allowed = permissions.can("roles.update")
      // if (!allowed) return response.status(400).json({ message: 'Validation error', errors: "Permission Denied" })

      /** Request validation */
      let validation = await request.validate({
        _id: "required|mongoId",
        // sign_out : "required|string"
       // sign_out : "Date"
      })
      if (validation && validation.length)
        return response
          .status(400)
          .json({ message: "Validation error", errors: validation })

    //  request.body.updated_by = request.user.email



    let filters = await request.filter({
      search: "LIKE:name",
      skip: "skip:0",
      limit: "limit",
      sort: "sort:_id",
      order: "order:1",
    })
    
    let total = await this.attendence_model.countDocuments(filters.find)

   console.log("total ", total)




    let attendence = await this.attendence_model.find({ user_id: request.params._id});
  //  let attendence = await this.attendence_model.find({});
  //  response.json(attendence)

    attendence.forEach(element => {
    //  console.log(element);
    });

    let len = attendence.length
    var last_attendence = attendence[len-1]
//    console.log(last_attendence)
    var attendence_date = last_attendence.stay_time;
//    console.log(attendence_date);
    var attendence_id = last_attendence._id
    var signed_in = attendence_date[0]['sign_in']

//    console.log(attendence_id)
//    console.log(signed_in)

    

      let updated = await this.attendence_model.findOneAndUpdate(
       
        { _id: attendence_id },
        {
          $set: {
            stay_time : {
            sign_in : signed_in,
            sign_out : request.body.sign_out
          } } 
        },
        { new: true, useFindAndModify: false }
      )
  
      /** Response */
      return response
        .status(200)
        .json({ message: "Attendence updated successfully", attendence: updated })
    } catch (err) {
      logger.log({
        level: "error",
        message: err,
      })
      return response.status(400).send({ message: "Something went wrong" })
    }
  }

  /**
   * @method destroy
   * @description delete attendence
   * @param {object} request
   * @param {object} response
   * @return {object} response
   */
  async destroy(request, response) {
    try {
      /** Permission validation */

      // let allowed = permissions.can("roles.delete")
      // if (!allowed) return response.status(400).json({ message: 'Validation error', errors: "Permission Denied" })

      /** Request validation */
      let result = await request.validate({
        _id: "required|mongoId",
      })
      if (result && result.length)
        return response
          .status(400)
          .json({ message: "Validation error", errors: result })
      let team = await this.attendence_model.findOne({ _id: request.params._id })

      if (!team) {
        return response.status(400).json({ message: "Attendence does not exists" })
      }
      let users = await this.attendence_model.find({
        attendence: team._id,
      })
      for (let i = 0;i < users.length;i++) {
        if (users[i].role && users[i].role.length)
          users[i].role = users[i].role.filter(function (value) {
            return value != request.params.id
          })
        users[i].save()
      }
      team.remove()

      /** Response */
      return response.status(200).json({ message: "Attendence deleted successfully" })
    } catch (err) {
      logger.log({
        level: "error",
        message: err,
      })
      return response.status(400).send({ message: "Something went wrong" })
    }
  }

  /**
   * @method findRelation
   * @description checks if a relation exists
   * @param {object} request
   * @param {object} response
   * @return {boolean} response
   */
  async findRelation(_id) {
    let found = null;
    found = await user_model.find({ roles: { $in: mongoose.Types.ObjectId(_id) } })
    if (found && found.length)
      return true
    return false
  }
}
