const mongoose = require("mongoose")
/**
 * @class AttendenceController
 * @description Handles all attendence related CRUD operations
 */
module.exports = class AttendenceController {
  /**
   * @constructor
   * @description Handles autoloaded dependencies
   */
  constructor(app) {
    this.attendence_model = app.get("AttendenceModel") // Role
    this.user_model = app.get("UserModel")
  }

  /**
   * @method index
   * @description Returns list of attendence
   * @param {object} request
   * @param {object} response
   * @return {image} response
   */
  async index(request, response) {
    try {

     
      let filters = await request.filter({
        search: "LIKE:name",
        skip: "skip:0",
        limit: "limit",
        sort: "sort:_id",
        order: "order:1",
      })

      

if (request.user.type === 'user'){
  filters.find['user_id'] = request.user._id         
}


if(request.query.user !== undefined && request.query.user != ''){
  filters.find['user_id'] = request.query.user
}


if(request.query.date !== undefined && request.query.date != ''){
  filters.find['created_at']= { 
    $gte: new Date(request.query.date).setUTCHours(0,0,0,0),
    $lte : new Date(request.query.date).setUTCHours(23,59,59,999)
  }
}

console.log(filters.find)

  let attendence = await this.attendence_model
    .find(filters.find)
    .populate({
      path: 'user_id',
      populate: [
        {
          path: 'team',
        }
        
      ],
    })
    .skip(filters.query.skip)
    .limit(filters.query.limit)
    .sort(filters.query.sort)
    .select(filters.projection)
    .lean()

 

  
    let total = await this.attendence_model.countDocuments(filters.find)


  
    
attendence.forEach(async(team) => {
let user = team.user_id
//console.log(user)
user = await this.user_model.find( {team : request.query.team}).populate('team')
if( request.query.team !== undefined && request.query.team != '' ) {
  filters.find['team'] = request.query.team
}

console.log(user.team)



})  

      /** Response */
      return response.status(200).json({
        pagination: {
          skip: filters.query.skip,
          limit: filters.query.limit,
          total,
        },
        attendence,
      })
 
    } catch (err) {
      logger.log({
        level: "error",
        message: err,
      })
      console.log(err)
      return response.status(400).send({ message: "Something went wrong" })
    }
  }


  /**
   * @method store
   * @description Create new attendence
   * @param {object} request
   * @param {object} response
   * @return {object} response
   */
  async store(request, response) {
    try {
      
      /** Permission validation */
      // let allowed = permissions.can("roles.create")
      // if (!allowed) return response.status(400).json({ message: 'Validation error', errors: "Permission Denied" })

      /** Request validation */
      let validation = await request.validate({
 //       user_id : "required|mongoId",
        sign_in : "required|string"
      })
//      console.log(request.user._id)
      if (validation && validation.length)
        return response
          .status(400)
          .json({ message: "Validation error", errors: validation })

        
        let current_date = new Date()
        // in 2023-03-26T19:56:31.281Z, time is changing continously and we want date only so we are using toDateString() to get date only.
        current_date = current_date.toDateString()
        let user_id = request.user._id
        let today_attendance = await this.attendence_model.findOne({user_id: user_id}, {}, { sort: { 'created_at' : -1 } })

        // to match today's date with last marked attendence, we use toDateString() to get date only skipping time
        if  ( today_attendance == null || current_date !=  today_attendance.created_at.toDateString() ) {
           let attendence = await this.attendence_model.create({
            user_id : request.user._id,
            date : request.body.date,
            attendence : [ {
              sign_in : request.body.sign_in,
              sign_out : null
            }          
            ] 
          })
          return response.status(200).json({
            message: "Attendence created successfully",
            attendence: attendence,
          })

        }
        else 
        if ( current_date ==  today_attendance.created_at.toDateString()  ) {

          let stay_time_count = today_attendance.attendence.length -1
          let sign_out_value = today_attendance.attendence[stay_time_count].sign_out
            if ( sign_out_value == null ) {
            return response.status(200).json({
              message: "Attendence already marked, need to sign out first"
            })

            
          }
          else {
            
            const newStayTime = {
              sign_in: request.body.sign_in,
              sign_out: null
            }

            let new_time = [...today_attendance.attendence, newStayTime]

            let updated = await this.attendence_model.findOneAndUpdate(
              { _id : today_attendance._id },
              { $set: { attendence: new_time } },
              { new: true, useFindAndModify: false },
              (err, doc) => {
                if (err) {
                    console.log("Something wrong when updating data!",err)
                }
            
                console.log(doc)
            }
            )

    
            return response
            .status(200)
            .json({ message: "Attendence pushed successfully", result: updated })

          }
          
        }
        return response.status(200).json({
          message: "System not working properly."
        })
      

        
      
    } catch (err) {
      logger.log({
        level: "error",
        message: err,
      })
      return response.status(400).send({ message: "Something went wrong" })
    }
  }







  /**
   * @method show
   * @description Returns single Attendence based on provided id
   * @param {object} request
   * @param {object} response
   * @return {object} response
   */
  async show(request, response) {
    try {
      let filters = await request.filter({
        search: "LIKE:name",
        skip: "skip:0",
        limit: "limit",
        sort: "sort:_id",
        order: "order:1",
      })

      /** Request validation */
      let result = await request.validate({
        // created_at: "required|mongoId",
      })
      if (result && result.length)
        return response
          .status(400)
          .json({ message: "Validation error", errors: result })

      if(request.query.date !== undefined && request.query.date != ''){
        filters.find['created_at']= { 
          $gte: new Date(request.query.date).setUTCHours(0,0,0,0),
          $lte : new Date(request.query.date).setUTCHours(23,59,59,999)
        }
      }

      console.log(filters.find)

      let attendence = await this.attendence_model.find(filters.find)
      // if (!attendence)
      //   return response.status(400).json({ message: "Attendence does not exist" })

      /** Response */
       return response.status(200).json(attendence)
    } catch (err) {
      logger.log({
        level: "error",
        message: err,
      })
      return response.status(400).send({ message: "Something went wrong" })
    }
  }







  /**
   * @method update
   * @description Update attendence
   * @param {object} request
   * @param {object} response
   * @return {object} response
   */
  async update(request, response) {
    try {
      /** Permission validation */

      // let allowed = permissions.can("roles.update")
      // if (!allowed) return response.status(400).json({ message: 'Validation error', errors: "Permission Denied" })

      /** Request validation */
      let validation = await request.validate({
        _id: "required|mongoId",
      })
      if (validation && validation.length)
        return response
          .status(400)
          .json({ message: "Validation error", errors: validation })

          
    let filters = await request.filter({
      search: "LIKE:name",
      skip: "skip:0",
      limit: "limit",
      sort: "sort:_id",
      order: "order:1",
    })
    
    //let total = await this.attendence_model.countDocuments(filters.find)


    let attendence = await this.attendence_model.findOne({ user_id: request.params._id}, {},  { sort: { 'created_at' : -1 } } )

    var attendence_stay_time = attendence.attendence
    //var attendence_stay_time_length = attendence.attendence.length
    
    let attendence_stay_time_count = attendence_stay_time.length
 
    if (attendence_stay_time_count == 1 && attendence.attendence[0].sign_out == null) {
      let signed_in = attendence_stay_time[0].sign_in
      let updated = await this.attendence_model.findOneAndUpdate(
       
      { _id: attendence._id },
      {
        $set: {
            attendence : {
            sign_in : signed_in,
            sign_out : request.body.sign_out
          }
        } 
      },
      { new: true, useFindAndModify: false }
       )
  
      
      return response
      .status(200)
         .json({ message: "Attendence updated successfully", attendence: updated })
    }
    
    var attendence_id = attendence._id
    var signed_out = attendence_stay_time[attendence_stay_time_count-1]['sign_out']

    let stay_time_obj = attendence_stay_time[attendence_stay_time_count-1]

    if ( signed_out == null) {
     
      let stayTime_id = stay_time_obj._id
      let stayTime_id_sign_in = stay_time_obj.sign_in
      let updated = await this.attendence_model.findOneAndUpdate(
      
        { "attendence._id": stayTime_id },
        {
          $set: {
            "attendence.$.sign_in" : stayTime_id_sign_in,
            "attendence.$.sign_out" : request.body.sign_out
           // }
          } 
        },
        { new: true, useFindAndModify: false }
      )
    
        
        return response
        .status(200)
           .json({ message: "Attendence updated successfully!", attendence: updated })
      }

      else {
        return response
        .status(200)
           .json({ message: "Already logged out"})
      }

    
    

      // let updated = await this.attendence_model.findOneAndUpdate(
       
      // { _id: attendence_id },
      // {
      //   $set: {
      //       attendence : {
      //       sign_in : signed_in,
      //       sign_out : request.body.sign_out
      //     }
      //   } 
      // },
      // { new: true, useFindAndModify: false }
      //  )
  
      
      // return response
      // .status(200)
      //    .json({ message: "Attendence updated successfully", attendence: updated })
    } catch (err) {
      logger.log({
        level: "error",
        message: err,
      })
      return response.status(400).send({ message: "Something went wrong" })
    }
  }

  

  /**
   * @method destroy
   * @description delete attendence
   * @param {object} request
   * @param {object} response
   * @return {object} response
   */
  async destroy(request, response) {
    try {
      /** Permission validation */

      // let allowed = permissions.can("roles.delete")
      // if (!allowed) return response.status(400).json({ message: 'Validation error', errors: "Permission Denied" })

      /** Request validation */
      let result = await request.validate({
        _id: "required|mongoId",
      })
      if (result && result.length)
        return response
          .status(400)
          .json({ message: "Validation error", errors: result })
      let attendence = await this.attendence_model.findOne({ _id: request.params._id })

      if (!attendence) {
        return response.status(400).json({ message: "Attendence does not exists" })
      }
      let users = await this.attendence_model.find({
        attendence: attendence._id,
      })
      for (let i = 0;i < users.length;i++) {
        if (users[i].role && users[i].role.length)
          users[i].role = users[i].role.filter(function (value) {
            return value != request.params.id
          })
        users[i].save()
      }
      attendence.remove()

      /** Response */
      return response.status(200).json({ message: "Attendence deleted successfully" })
    } catch (err) {
      logger.log({
        level: "error",
        message: err,
      })
      return response.status(400).send({ message: "Something went wrong" })
    }
  }







  /**
   * @method getAttendence
   * @description Get Attendence
   * @param {object} request
   * @param {object} response
   * @return {object} response
   */
  async getAttendence(request, response) {
    try {
      /** Permission validation */

      // let allowed = permissions.can("roles.delete")
      // if (!allowed) return response.status(400).json({ message: 'Validation error', errors: "Permission Denied" })

      /** Request validation */
      let result = await request.validate({
        _id: "required|mongoId",
      })
      if (result && result.length)
        return response
          .status(400)
          .json({ message: "Validation error", errors: result })

          /** User */
          let user_id  = request.user._id

          // $gte : new Date(new Date(request.query.start_date).setHours(0,0,0,0))
          // $lte : new Date(new Date(request.query.end_date).setHours(23,59,59,999))

          
      //let presence = await this.attendence_model.find({ date: { $gte: new Date("2023,03,23"), $lte:new Date("2023,03,28") }, user_id: request.body.user })
      let presence = await this.attendence_model.find({ date: { $gte: request.query.start_date+'T00:00:00.000Z' , $lte: request.query.end_date+'T23:59:59.999Z' }, user_id: user_id })
       if (!presence) {
        return response.status(400).json({ message: "Attendence does not exists" })
      } else {
         return response.status(200).send(presence)
      }
    
    } catch (err) {
      logger.log({
        level: "error",
        message: err,
      })
      return response.status(400).send({ message: "Something went wrong" })
    }
  }






  /**
   * @method getAttendence
   * @description Get Attendence
   * @param {object} request
   * @param {object} response
   * @return {object} response
   */
  async getTeamAttendence(request, response) {
    try {
      
          /** User */
        let team_id  = request.params._id
        let all_users = await this.user_model.find({team : team_id})

        console.log(all_users)
        

        if (!all_users) {
           return response.status(400).json({ message: "Team does not exists" })
        } 
          
      //let presence = await this.attendence_model.find({ date: { $gte: new Date("2023,03,23"), $lte:new Date("2023,03,28") }, user_id: request.body.user })
      let presence = await this.attendence_model.find({ date: { $gte: request.query.start_date+'T00:00:00.000Z' , $lte: request.query.end_date+'T23:59:59.999Z' } })
        

//       loop of date(){
//         let totday = '2222'
// all user loop(){
//   let presence = await this.attendence_model.find({ date: { $gte: totday , $lte: totday },user_id:12222 })
// if(presence){

// }
// if(!sdfdf){

// }
// }


//       }
     

      function getDatesInRange(startDate, endDate) {
        const date = new Date(startDate);
      
        const dates = [];
      
        while (date <= endDate) {
          dates.push(new Date(date).toDateString());
          date.setDate(date.getDate() + 1);
        }
      
        return dates;
      }
      
      const d1 = new Date(request.query.start_date);
      const d2 = new Date(request.query.end_date);
      const showDate = getDatesInRange(d1, d2)
      console.log(showDate);

       if (!presence) {
        return response.status(400).json({ message: "Attendence does not exists" })
      } else {
         return response.status(200).send(presence)
      }


      
    
    } catch (err) {
      logger.log({
        level: "error",
        message: err,
      })
      return response.status(400).send({ message: "Something went wrong" })
    }
  }


}
