const mongoose = require("mongoose")
/**
 * @class LeaveController
 * @description Handles all leave related CRUD operations
 */
module.exports = class LeaveController {
  /**
   * @constructor
   * @description Handles autoloaded dependencies
   */
  constructor(app) {
    this.leave_model = app.get("LeavesModel")
    this.user_model = app.get("UserModel")

  }

  /**
   * @method index
   * @description Returns list of leaves
   * @param {object} request
   * @param {object} response
   * @return {image} response
   */
  async index(request, response) {
    try {
      /** Permission validation */
      // let allowed = permissions.can("roles.getAll")
      // if (!allowed) return response.status(400).json({ message: 'Validation error', errors: "Permission Denied" })

      /** Request validation */
      let filters = await request.filter({
        search: "LIKE:name",
        skip: "skip:0",
        limit: "limit",
        sort: "sort:_id",
        order: "order:1",
      })
      let leave = await this.leave_model
        //.find(filters.find)
        .find({user_id : request.user._id})
        // .populate("permissions")
        .skip(filters.query.skip)
        .limit(filters.query.limit)
        .sort(filters.query.sort)
        .select(filters.projection)
        .lean()
      
      //let total = await this.leave_model.countDocuments(filters.find)
      let total = await this.leave_model.countDocuments({user_id : request.user._id})

      /** Response */
      return response.status(200).json({
        pagination: {
          skip: filters.query.skip,
          limit: filters.query.limit,
          total,
        },
        leave,
      })
    } catch (err) {
      logger.log({
        level: "error",
        message: err,
      })
      console.log(err)
      return response.status(400).send({ message: "Something went wrong" })
    }
  }


  
  /**
   * @method store
   * @description Create new leave
   * @param {object} request
   * @param {object} response
   * @return {object} response
   */
  async store(request, response) {
    try {
      /** Permission validation */
      // let allowed = permissions.can("roles.create")
      // if (!allowed) return response.status(400).json({ message: 'Validation error', errors: "Permission Denied" })

      /** Request validation */
      let validation = await request.validate({
        user_id: "mongoId",
        leave_reason: "required|string",
        leave_type : "required|string",
        from: "required|date",
        till: "required|date",
        leave_status: "string",
        approved_by: "string",
      })
      if (validation && validation.length)
        return response
          .status(400)
          .json({ message: "Validation error", errors: validation })


      if ( request.body.leave_type !== undefined || request.body.leave_type !== '') {
        const leve = request.body.leave_type
        const leaves_consumed = await this.leave_model.countDocuments({ user_id: request.user._id, leave_type: leve})
        console.log('ann ', leaves_consumed)
        let remaining_leaves = 8 - leaves_consumed
        console.log('rem ', remaining_leaves)
        var remained_leaves = remaining_leaves + ' ' + leve +  ' leaves remaining'
        console.log('rema ', remained_leaves)
        if (remaining_leaves <= 0) {
            return response.json({
              mesasge: "You reached max limit of annual leaves",
              remaining_leave : 0,
              total_annual_leaves : 8 
            })
        }
      }

      // let check_medical_leaves = await this.leave_model.countDocuments({ user_id: request.user._id, leave_type: 'medical'})
      // if (check_medical_leaves >= 8) {
      //   return response.send({ 'Message' :'You reached max limit of medical leaves' })
      // }
      // console.log('med ',check_medical_leaves);

      // let check_casual_leaves = await this.leave_model.countDocuments({ user_id: request.user._id, leave_type: 'casual'})
      // if (check_casual_leaves >= 8) {
      //   return response.send({ 'Message' :'You reached max limit of casual leaves'})
      // }
      // console.log('cas ',check_casual_leaves);
  


      let lead = await this.user_model.findOne({'team': request.user.team,'designation' : 'lead'})
      request.body.assign_to = lead._id
      /** Response */

      
      
      let leave = await this.leave_model.create({
        user_id: request.user._id,
        leave_reason: request.body.leave_reason,
        leave_type : request.body.leave_type,
        from: request.body.from,
        till: request.body.till,
        leave_status: 'pending',
        approved_by: request.body.approved_by,
        assign_to : request.body.assign_to
      })




      return response.status(200).json({
        total : 8,
       // "leave_used" : leaves_consumed,
        remaining_leaves : remained_leaves,
        message: "Leave created successfully ",
        leave: leave,
      })
    } catch (err) {
      logger.log({
        level: "error",
        message: err,
      })
      return response.status(400).send({ message: "Something went wrong" })
    }
  }

  /**
   * @method show
   * @description Returns single leave based on provided id
   * @param {object} request
   * @param {object} response
   * @return {object} response
   */
  async show(request, response) {
    try {
      /** Permission validation */
      // let allowed = permissions.can("roles.getOne")
      // if (!allowed) return response.status(400).json({ message: 'Validation error', errors: "Permission Denied" })

      /** Request validation */
      let result = await request.validate({
        user_id: "required|mongoId",
      })
      if (result && result.length)
        return response
          .status(400)
          .json({ message: "Validation error", errors: result })
      let leave = await this.leave_model.findOne({ _id: request.params._id })
      if (!leave)
        return response.status(400).json({ message: "Leave does not exist" })

      /** Response */
      return response.status(200).json(leave)
    } catch (err) {
      logger.log({
        level: "error",
        message: err,
      })
      return response.status(400).send({ message: "Something went wrong" })
    }
  }

  /**
   * @method update
   * @description Update leave
   * @param {object} request
   * @param {object} response
   * @return {object} response
   */
  async update(request, response) {
    try {
      /** Permission validation */

      // let allowed = permissions.can("roles.update")
      // if (!allowed) return response.status(400).json({ message: 'Validation error', errors: "Permission Denied" })

      /** Request validation */
      let validation = await request.validate({
        user_id: "mongoId|required",
        leave_reason: "string",
        from: "date",
        till: "date",
        leave_status: "string",
        approved_by: "string",

      })
      if (validation && validation.length)
        return response
          .status(400)
          .json({ message: "Validation error", errors: validation })

        request.body.updated_by = request.user.email

      let updated = await this.leave_model.findOneAndUpdate(
        { _id: request.params._id },
        {
          $set: request.body,
        },
        { new: true, useFindAndModify: false }
      )

      /** Response */
      return response
        .status(200)
        .json({ message: "Leave updated successfully", leave: updated })
    } catch (err) {
      logger.log({
        level: "error",
        message: err,
      })
      return response.status(400).send({ message: "Something went wrong" })
    }
  }

  /**
   * @method destroy
   * @description delete role
   * @param {object} request
   * @param {object} response
   * @return {object} response
   */
  async destroy(request, response) {
    try {
      /** Permission validation */

      // let allowed = permissions.can("roles.delete")
      // if (!allowed) return response.status(400).json({ message: 'Validation error', errors: "Permission Denied" })

      /** Request validation */
      let result = await request.validate({
        _id: "required|mongoId",
      })
      if (result && result.length)
        return response
          .status(400)
          .json({ message: "Validation error", errors: result })
      let leave = await this.leave_model.findOne({ _id: request.params._id })

      if (!leave) {
        return response.status(400).json({ message: "leave does not exists" })
      }
      let users = await this.leave_model.find({
        leave: leave._id,
      })
      for (let i = 0; i < users.length; i++) {
        if (users[i].leave && users[i].leave.length)
          users[i].leave = users[i].leave.filter(function (value) {
            return value != request.params.id
          })
        users[i].save()
      }
      leave.remove()

      /** Response */
      return response.status(200).json({ message: "Leave deleted successfully" })
    } catch (err) {
      logger.log({
        level: "error",
        message: err,
      })
      return response.status(400).send({ message: "Something went wrong" })
    }
  }

  /**
   * @method findRelation
   * @description checks if a relation exists
   * @param {object} request
   * @param {object} response
   * @return {boolean} response
   */
  async findRelation(_id) {
    let found = null;
    found = await user_model.find({ roles: { $in: mongoose.Types.ObjectId(_id) } })
    if (found && found.length)
      return true
    return false
  }
}
