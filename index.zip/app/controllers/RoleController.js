const mongoose = require("mongoose")
/**
 * @class RoleController
 * @description Handles all role related CRUD operations
 */
module.exports = class RoleController {
  /**
   * @constructor
   * @description Handles autoloaded dependencies
   */
  constructor(app) {
    this.role_model = app.get("RoleModel") // Role
    this.user_model = app.get("UserModel")

  }

  /**
   * @method index
   * @description Returns list of role
   * @param {object} request
   * @param {object} response
   * @return {image} response
   */
  async index(request, response) {
    try {
      /** Permission validation */
      // let allowed = permissions.can("roles.getAll")
      // if (!allowed) return response.status(400).json({ message: 'Validation error', errors: "Permission Denied" })

      /** Request validation */
      let filters = await request.filter({
        search: "LIKE:name",
        skip: "skip:0",
        limit: "limit",
        sort: "sort:_id",
        order: "order:1",
      })
      let role = await this.role_model
        .find(filters.find)
        // .populate("permissions")
        .skip(filters.query.skip)
        .limit(filters.query.limit)
        .sort(filters.query.sort)
        .select(filters.projection)
        .lean()
      let total = await this.role_model.countDocuments(filters.find)

      if (request.query.test != undefined || request.query.test != '' ) {
        console.log('yes');
      }

      /** Response */
      return response.status(200).json({
        pagination: {
          skip: filters.query.skip,
          limit: filters.query.limit,
          total,
        },
        role,
      })
    } catch (err) {
      logger.log({
        level: "error",
        message: err,
      })
      return response.status(400).send({ message: "Something went wrong" })
    }
  }



  /**
   * @method store
   * @description Create new role
   * @param {object} request
   * @param {object} response
   * @return {object} response
   */
  async store(request, response) {
    try {
      /** Permission validation */
      // let allowed = permissions.can("roles.create")
      // if (!allowed) return response.status(400).json({ message: 'Validation error', errors: "Permission Denied" })

      /** Request validation */
      let validation = await request.validate({
        type: "required|string",
      })
      if (validation && validation.length)
        return response
          .status(400)
          .json({ message: "Validation error", errors: validation })


      /** Response */
      let role = await this.role_model.create(request.body)
      return response.status(200).json({
        message: "role created successfully",
        role: role,
      })
    } catch (err) {
      logger.log({
        level: "error",
        message: err,
      })
      return response.status(400).send({ message: "Something went wrong" })
    }
  }

  /**
   * @method show
   * @description Returns single role based on provided id
   * @param {object} request
   * @param {object} response
   * @return {object} response
   */
  async show(request, response) {
    try {
      /** Permission validation */
      // let allowed = permissions.can("roles.getOne")
      // if (!allowed) return response.status(400).json({ message: 'Validation error', errors: "Permission Denied" })

      /** Request validation */
      let result = await request.validate({
        _id: "required|mongoId",
      })
      if (result && result.length)
        return response
          .status(400)
          .json({ message: "Validation error", errors: result })
      let role = await this.role_model.findOne({ _id: request.params._id })
      if (!role)
        return response.status(400).json({ message: "Role does not exist" })

      /** Response */
      return response.status(200).json(role)
    } catch (err) {
      logger.log({
        level: "error",
        message: err,
      })
      return response.status(400).send({ message: "Something went wrong" })
    }
  }

  /**
   * @method update
   * @description Update role
   * @param {object} request
   * @param {object} response
   * @return {object} response
   */
  async update(request, response) {
    try {
      /** Permission validation */

      // let allowed = permissions.can("roles.update")
      // if (!allowed) return response.status(400).json({ message: 'Validation error', errors: "Permission Denied" })

      /** Request validation */
      let validation = await request.validate({
        _id: "required|mongoId",
        type: "string",
      })
      if (validation && validation.length)
        return response
          .status(400)
          .json({ message: "Validation error", errors: validation })

      request.body.updated_by = request.user.email

      let updated = await this.role_model.findOneAndUpdate(
        { _id: request.params._id },
        {
          $set: request.body,
        },
        { new: true, useFindAndModify: false }
      )

      /** Response */
      return response
        .status(200)
        .json({ message: "Role updated successfully", role: updated })
    } catch (err) {
      logger.log({
        level: "error",
        message: err,
      })
      return response.status(400).send({ message: "Something went wrong" })
    }
  }

  /**
   * @method destroy
   * @description delete role
   * @param {object} request
   * @param {object} response
   * @return {object} response
   */
  async destroy(request, response) {
    try {
      /** Permission validation */

      // let allowed = permissions.can("roles.delete")
      // if (!allowed) return response.status(400).json({ message: 'Validation error', errors: "Permission Denied" })

      /** Request validation */
      let result = await request.validate({
        _id: "required|mongoId",
      })
      if (result && result.length)
        return response
          .status(400)
          .json({ message: "Validation error", errors: result })
      let role = await this.role_model.findOne({ _id: request.params._id })

      if (!role) {
        return response.status(400).json({ message: "Role does not exists" })
      }
      let users = await this.user_model.find({
        role: role._id,
      })
      for (let i = 0;i < users.length;i++) {
        if (users[i].role && users[i].role.length)
          users[i].role = users[i].role.filter(function (value) {
            return value != request.params.id
          })
        users[i].save()
      }
      role.remove()

      /** Response */
      return response.status(200).json({ message: "Role deleted successfully" })
    } catch (err) {
      logger.log({
        level: "error",
        message: err,
      })
      return response.status(400).send({ message: "Something went wrong" })
    }
  }

  /**
   * @method findRelation
   * @description checks if a relation exists
   * @param {object} request
   * @param {object} response
   * @return {boolean} response
   */
  async findRelation(_id) {
    let found = null;
    found = await user_model.find({ roles: { $in: mongoose.Types.ObjectId(_id) } })
    if (found && found.length)
      return true
    return false
  }
}
