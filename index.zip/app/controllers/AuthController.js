/**
 * @class AuthController
 * @description Handles user authentication
 */
module.exports = class AuthController {
  /**
   * @constructor
   * @description Handles autoloaded dependencies
   */
  constructor(app) {
    this.user_model = app.get('UserModel')
    this.crypt_helper = app.get('CryptHelper')
    this.auth_validator = app.get('AuthValidator')
  }

  /**
   * @method login
   * @description Returns successfully logged in user and passport bearer token
   * @param {object} request
   * @param {object} response
   * @return {object} response
   */
  async login(request, response) {
    try {

      /** Request validation */
      let validation = this.auth_validator.validateLogin(request, response)
      if (validation.error)
        return response.status(400).send({ message: 'Validation error', errors: validation.errors })

      var user = await this.user_model.findOne({ email: request.body.email })
      if (!user) return response.status(400).send({ message: 'Invalid Credentials' })
      if (user.status == 'pending' || user.status == 'blocked') {
        return response.status(400).json({ message: 'Email not verified or the user is blocked.' })
      }

      if (request.body.password === '') {
        return response.status(400).json({ message: 'Password is required' })
      }
      if (!request.body.google_login) {
        let generated_password = auth.hashPassword(request.body.password, Config.app('salt'))
        if (generated_password !== user.password) {
          return response.status(400).json({ message: 'Email or Password mismatched.' })
        }
        user
        delete user.password
      }
      let updated_user = await this.user_model.findOneAndUpdate(
        { _id: user._id },
        {
          $set: {
            last_login: new Date(),
          },
        },
        { new: true, useFindAndModify: false }
      )
      // user = this.user_model.find({})populate('roles')
      permissions.current = []
      response.status(200).json({
        user: updated_user,
        token: auth.generateToken(user.id.toString()),
      })
    } catch (err) {
      logger.log({
        level: 'error',
        message: err,
      })
      return response.status(400).send({ message: 'Email or Password mismatched.' })
    }
  }

  /**
   * @method logs
   * @description Returns logs string
   * @param {object} request
   * @param {object} response
   * @return {object} response
   */
  async logs(request, response) {
    try {
      let data = fs.readFileSync(root_directory + 'logs/error.log', 'utf8')
      data = data.replace(/    /g, '&nbsp;&nbsp;&nbsp;&nbsp;')
      data = data.replace(/(?:\r\n|\r|\n)/g, '<br>')
      response.status(200).send(data)
    } catch (err) {
      logger.log({
        level: 'error',
        message: err,
      })
      return response.status(400).send({ message: 'Something went wrong' })
    }
  }

  /**
   * @method changePassword
   * @description Changed password of user
   * @param {object} request
   * @param {object} response
   * @return {object} response
   */
  async changePassword(request, response) {
    try {
      /** Request validation */
      let validation = this.auth_validator.validateChangePassword(request, response)
      if (validation.error)
        return response.status(400).send({ message: 'Validation error', errors: validation.errors })

      let user = await this.user_model.findOne({ _id: request.user._id })
      if (user == null) {
        return response.status(200).json({ message: 'User does not exist' })
      }
      if (request.body.current_password === '' && request.body.new_password === '') {
        return response
          .status(400)
          .json({ message: 'Previous Password and New Password are required' })
      }
      if (request.body.current_password === '' && request.body.new_password !== '') {
        return response.status(400).json({ message: 'Previous Password is required' })
      }
      if (request.body.current_password !== '' && request.body.new_password === '') {
        return response.status(400).json({ message: 'New Password is required' })
      }

      let generated_password = auth.hashPassword(request.body.current_password, Config.app('salt'))
      if (generated_password !== request.user.password) {
        return response.status(200).json({ message: 'Invalid current password' })
      }

      let new_password = auth.hashPassword(request.body.new_password, Config.app('salt'))
      user.password = new_password
      let updated = await user.save()
      if (updated.updatedCount == 0)
        return response.status(400).json({ message: 'Unable to change password' })

      /** Response */
      return response.status(200).json({ message: 'Password changed successfully' })
    } catch (err) {
      logger.log({
        level: 'error',
        message: err,
      })
      return response.status(400).send({ message: 'Something went wrong' })
    }
  }

  /**
   * @method forgetPassword
   * @description Changed password of user
   * @param {object} request
   * @param {object} response
   * @return {object} response
   */
  async forgetPassword(request, response) {
    try {
      /** Request validation */
      let validation = this.auth_validator.validateForgetPassword(request, response)
      if (validation.error)
        return response.status(400).send({ message: 'Validation error', errors: validation.errors })

      let user = await this.user_model.findOne({ email: request.body.email })
      if (!user) {
        return response.status(400).json({ message: 'No user associated with provided email' })
      }

      // user.reset_password_token = auth.generateToken(user._id.toString())
      user.reset_password_token = this.crypt_helper.generateToken(user._id.toString())
      user.reset_password_created_at = Date.now() + 3600000 // 1 hour
      await user.save()

      /** Email dispatch */
      // let template = this.reset_password_email.template(
      //   user.reset_password_token,
      //   Config.app('base_url'),
      //   user.email,
      //   `${user.first_name} ${user.last_name}`,
      //   Config.app('app_name')
      // )
      let template = await view().render('templates.reset-password', {
        token: user.reset_password_token,
        base_url: Config.app('base_url'),
        name: `${user.first_name} ${user.last_name}`,
        app: Config.app('app_name'),
      })

      await mail.send(template, 'Forgot Password', user.email)

      /** Response */
      return response.status(200).send({ message: 'Email is sent successfully to user' })
    } catch (err) {
      logger.log({
        level: 'error',
        message: err,
      })
      return response.status(400).send({ message: 'Something went wrong' })
    }
  }

  /**
   * @method resetPassword
   * @description Changed password of user
   * @param {object} request
   * @param {object} response
   * @return {object} response
   */
  async resetPassword(request, response) {
    try {
      /** Request validation */
      let validation = this.auth_validator.validateResetPassword(request, response)
      if (validation.error)
        return response.status(400).send({ message: 'Validation error', errors: validation.errors })

      let user = await this.user_model.findOne({
        reset_password_token: request.params.token,
        reset_password_created_at: { $gt: Date.now() },
      })

      if (!user) {
        return response.status(400).json({ message: 'Invalid Token' })
      }

      if (request.body.password !== request.body.confirm_password) {
        return response.status(400).send({
          message: 'Passwords must be same.',
          errors: validation,
        })
      } else {
        user.password = auth.hashPassword(request.body.password, Config.app('salt'))
      }

      user.reset_password_token = null
      user.status = 'active'
      user.verified_at = new Date()
      let updated = await user.save()
      if (updated.updatedCount == 0)
        return response.status(400).json({ message: 'Unable to reset password' })

      /** Response */
      return response.status(200).json({ message: 'Your password has been reset successfully' })
    } catch (err) {
      logger.log({
        level: 'error',
        message: err,
      })
      return response.status(400).send({ message: 'Something went wrong' })
    }
  }
}
