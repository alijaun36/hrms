/**
 * @class offerStatus
 * @description run cron job to change the status of offers
 */
const fs = require('fs')
module.exports = class offerStatus {

    constructor() {

    }

    /**
     * @method run
     * @description Run automatically triggered when job runs
     */
    async run() {
        
    }

}