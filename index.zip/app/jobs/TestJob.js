/**
 * @class TestJob
 * @description A test job
 */
module.exports = class TestJob {

    constructor() {

    }

    /**
     * @method run
     * @description Run automatically triggered when job runs
     */
    async run() {
        
    }

}