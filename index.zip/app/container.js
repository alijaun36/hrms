/**
 * Container Class
 * @description Container allows to attach or preload dependencies
 */
module.exports = class container {
  constructor(app) {
    app
      .controller("AuthController")
      .inject(["models.UserModel", "helpers.CryptHelper"])
      .validators(["AuthValidator"])

    app.controller("PermissionController").inject(["models.PermissionModel", "models.RoleModel"])

    app
      .controller("RoleController")
      .inject(["models.RoleModel", "models.UserModel"])

    app
      .controller("UserController")
      .inject([
        "models.UserModel",
        "models.RoleModel",
      ])

      app.controller("TeamController").inject(["models.TeamModel"])
      app.controller("AttendenceController").inject(["models.AttendenceModel"])
      app.controller("LeaveController").inject(["models.LeavesModel"])
  
  }
}
