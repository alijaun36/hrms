module.exports = class UserSeeder {
  constructor() {
    this.user_model = resolveOnce('app.models.UserModel')
    this.role_model = resolveOnce('app.models.RoleModel')
    this.permissions = {
      all: [],
      admin: [],
      hr: [],
      cto: [],
      manager: [],
      gm: [],
      lead: [],
    }
  }

  async up() {
    var global_role = ''
    let user_type = ['admin', 'hr', 'cto', 'manager', 'gm', 'lead']

    for (let i = 0; i < user_type.length; i++) {
      let role_exists = await this.role_model.findOne({ type: user_type[i] })

      if (
        role_exists &&
        role_exists.permissions &&
        role_exists.permissions.length === permissions.all.length
      ) {
        global_role = user_type[i] == 'admin' ? role_exists._id : global_role
        console.log('Role already seeded.')
      } else if (
        role_exists
      ) {
        let updated_role = await this.role_model.findOneAndUpdate(
          { type: user_type[i] },
          { $set: { permissions: permissions.all } },
          { new: true, useFindAndModify: false }
        )
        //role_exists.update({$set: permissions.all})
        global_role = user_type[i] == 'admin' ? updated_role._id : global_role
        console.log('Role Updated successfully.')
      } else {
        let role = await this.role_model.create({
          name: user_type[i],
          type: user_type[i],
          permissions: permissions.all,
        })
        global_role = user_type[i] == 'admin' ? role._id : global_role
        console.log('Role seeded successfully', role)
      }
    }
    let user_exists = await this.user_model.find({
      email: 'admin@roadie.com',
    })

    if (user_exists.length == 0) {
      let user_response = await this.user_model.create({
        first_name: 'super',
        last_name: 'admin',
        email: 'admin@roadie.com',
        password: auth.hashPassword('12345678', Config.app('salt')),
        type: 'admin',
        status: 'active',
        roles: global_role,
        blocked_at: null,
        created_at: new Date(),
        updated_at: new Date(),
      })
    } else {
      await this.user_model.findOneAndUpdate(
        { email: 'admin@roadie.com' },
        { $set: { roles: global_role } },
        { new: true, useFindAndModify: false }
      )
      console.log('User already seeded.')
    }
  }
}
