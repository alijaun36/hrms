/**
 * Api routes
 * @description All api related routes can be defined here accordingly
 */

/**
 * @prefix /api/v1
 * @description Prefix {/api/v1} will be prepended all routes urls
 */
// Router.prefix('/api/v1')

/** Test route */
Router.get('/test', (request, response) => {
  return response.status(200).send({ message: 'OK' })
})

/* Testing Purpose */
Router.post('/register', 'AuthController@register')

/** Open auth routes */
Router.get('/logs', 'AuthController@logs')
Router.post('/login', 'AuthController@login')
Router.post('/auth/forget-password', 'AuthController@forgetPassword')
Router.post('/auth/reset-password/:token', 'AuthController@resetPassword')
Router.get('/user/profile-image/:filename', 'UserController@profileImage')
// Router.get('/user/profile-image/:filename', 'PassengerController@profileImage')
Router.get('/vehicle/vehicle_images/:filename', 'VehicleController@profileImage')
Router.get('/user/liscence_images/:filename', 'DriverController@liscenceImage')

//Router.post('/user', 'UserController@store')

// Router.get('/invoice/download/:filename', function (request, response) {
// settings routes
Router.get('/setting', 'SettingController@index')
Router.get('/setting/:_id', 'SettingController@show')
// mobile settings routes
Router.get('/mobile-setting', 'MobileSettingController@index')
Router.get('/mobile-setting/:_id', 'MobileSettingController@show')

//   let file_path = root_directory + "/public/invoice_files/" + request.params.filename
//   response.download(file_path); // Set disposition and send it.
// });

/**
 * @middleware app.middlewares.passport
 * @description Passport middleware will be applied to all routes inside callback function
 */
Router.middleware(['app.middlewares.passport'], _router => {
  /** General routes */
  Router.post('/auth/change-password', 'AuthController@changePassword')

  /** Protected User Routes */
  // _router.get('/admin/:_id', 'UserController@show')
  // _router.put('/admin/:_id', 'UserController@update')
  _router.get('/user/:_id', 'UserController@show')
  _router.post('/user', 'UserController@store')
  _router.get('/user', 'UserController@index')
  _router.delete('/user/:_id', 'UserController@destroy')
  _router.put('/user/:_id', 'UserController@update')
  _router.put('/user/reset-password/:_id', 'UserController@resetPassword')
  _router.post('/user/leaves', 'UserController@leave_approval')

  

  /** Protected Permission Routes */
  _router.get('/permission', 'PermissionController@index')
  _router.post('/permission', 'PermissionController@store')
  _router.get('/permission/:_id', 'PermissionController@show')
  _router.put('/permission/:_id', 'PermissionController@update')
  _router.delete('/permission/:_id', 'PermissionController@destroy')

  /** Protected Role Routes */
  _router.get('/role', 'RoleController@index')
  _router.post('/role', 'RoleController@store')
  _router.get('/role/:_id', 'RoleController@show')
  _router.put('/role/:_id', 'RoleController@update')
  _router.delete('/role/:_id', 'RoleController@destroy')



  _router.post('/team', 'TeamController@store')
  _router.get('/team', 'TeamController@index')
  _router.get('/team/:_id', 'TeamController@show')
  _router.put('/team/:_id', 'TeamController@update')
  _router.delete('/team/:_id', 'TeamController@destroy')


  _router.post('/attendence', 'AttendenceController@store')
  _router.get('/attendence', 'AttendenceController@index')
  _router.get('/attendance-date', 'AttendenceController@show')
  _router.put('/attendence/:_id', 'AttendenceController@update')
  _router.delete('/attendence/:_id', 'AttendenceController@destroy')
  _router.get('/get_attendence/:_id', 'AttendenceController@getAttendence')
  _router.get('/get_team_attendence/:_id', 'AttendenceController@getTeamAttendence')


  _router.post('/leave', 'LeaveController@store')
  _router.get('/leave', 'LeaveController@index')
  _router.get('/leave/:_id', 'LeaveController@show')
  _router.put('/leave/:_id', 'LeaveController@update')
  _router.delete('/leave/:_id', 'LeaveController@destroy')



})
