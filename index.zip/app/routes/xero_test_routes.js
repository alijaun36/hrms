
Router.middleware(["app.middlewares.passport"], (_router) => {
    
    _router.get("/xero-test", "XeroTestController@createInvoice")
    
})
