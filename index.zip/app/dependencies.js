/**
 * @description Define and auto load/resolve all dependencies required inside of application
 */
module.exports = [
  {
    module: "app",
    resolve: [
      {
        controllers: ["controllers.UserController"],
        dependencies: [
          {
            targets: [
              "models.UserModel",
              "validators.UserValidator",
              "helpers.CryptHelper",
            ],
          },
        ],
      },
    ],
  },
];
