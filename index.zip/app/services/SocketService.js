const { Server } = require("socket.io")

/**
 * @class SocketService
 * @description Service for Socket
 * @howTo
 * - npm install socket.io
 * - app/hooks.js > boot() > app.loadService('permissions', 'app.services.SocketService')
 */

module.exports = class SocketService {

    constructor(app) {
        if (Config.app('debug')) console.log("* SocketService")

        this.io = new Server(__server_instance, { cors: { origin: "*" } })
        this.user_model = resolveOnce('app.models.UserModel')

        this.io.on('connection', async (socket) => {

            const { id, handshake: { query: { user_id } } } = socket
            await this.user_model.findOneAndUpdate(
                { _id: user_id },
                { $set: { socket_id: socket.id } },
                { new: true, useFindAndModify: false }
            )

            socket.on('disconnect', async () => {
                await this.user_model.findOneAndUpdate(
                    { _id: user_id },
                    { $set: { socket_id: null } },
                    { new: true, useFindAndModify: false }
                )
            })

            socket.on('send_message', async ({receiver_id, message}) => {
                // data = data.split("?user_id=");
                // let receiver_id = data[1]
                const _receiver = await this.user_model.findOne({ _id: receiver_id }).select({ socket_id: 1 })
                if (_receiver) {
                    this.io.to(_receiver.socket_id).emit('receive_message', message)
                }
            })
        })


    }



}