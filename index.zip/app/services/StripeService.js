const Stripe = require("stripe")
/**
 * @class StripeService
 * @description Service for Stripe
 * @howTo
 * - npm install --save stripe
 * - app/hooks.js > boot() > app.loadService('permissions', 'app.services.StripeService')
 */
module.exports = class StripeService {

    constructor(app) {
         if(Config.app('debug')) console.log("* MongoService")
        if (Config.app('debug'))
            this.stripe = Stripe(Config.get('stripe.stripe_key'))
    }

    async createBank(country, account_holder_name, account_holder_type, routing_number, account_number) {
        let token = await this.stripe.tokens.create({
            bank_account: {
                country: country,
                currency: Config.app('stripe.stripe_currency'),
                account_holder_name: account_holder_name,
                account_holder_type: account_holder_type, //individual
                routing_number: routing_number,
                account_number: account_number,
            },
        })
        return token
    }

    async createCard(number, exp_month, exp_year, cvc) {
        let token = await this.stripe.tokens.create({
            card: {
                number: number,
                exp_month: exp_month,
                exp_year: exp_year,
                cvc: cvc,
            },
        })
        return token
    }

    async authorizeCharge(token, amount, description) {
        let charge = await this.stripe.charges.create({
            amount: amount,
            currency: Config.get('stripe.stripe_currency'),
            source: token,
            description: description === undefined ? '' : description,
            capture: false
        })
        return charge
    }

    async charge(token, amount, description) {
        let charge = await this.stripe.charges.create({
            amount: parseFloat(amount),
            currency: Config.get('stripe.stripe_currency'),
            source: token,
            description: description === undefined ? '' : description,
            capture: true
        })
        return charge
    }

    async captureCharge(token) {
        let charge = await this.stripe.charges.capture(token)
        return charge
    }

    async getCharge(token) {
        let charge = await this.stripe.charges.retrieve(token)
        return charge
    }

    async createCustomer(card_token) {
        let customer = await this.stripe.customers.create({
            source: card_token
        })
        return customer
    }

    async addCustomerCards(customer_id, card_token) {
        let customer = await this.stripe.customers.createSource(
            customer_id, { source: card_token }
        )
        return customer
    }

    async payWithCustomerId(stripe_customer_id, amount, card_token) {
        let charge = await this.stripe.charges.create({
            amount: parseFloat(amount),
            currency: Config.get('stripe.stripe_currency'),
            customer: stripe_customer_id,
            source: card_token,
            description: 'description',
            capture: true
        })
        return charge
    }

    async deleteCustomerCard(customer_id, card_token) {
        const deleted = await this.stripe.customers.deleteSource(
            customer_id,
            card_token
        )
        return deleted
    }

    async refundPayment(payment_id) {
        let refund = await this.stripe.refunds.create({ charge: payment_id })
        return refund
    }

}