const XeroClient = require('xero-node').XeroClient
// var mime = require('mime-types')

/**
 * @class XeroService
 * @description Service for permissions
 * @howTo
 * - npm install xero-node --save
 * - app/hooks.js > boot() > app.loadService('permissions', 'app.services.XeroService')
 */
module.exports = class XeroService {

    constructor(app) {
        if (Config.app('debug')) console.log("* XeroService")

        this.client = new XeroClient({
            clientId: Config.get('xero.client_id'),
            clientSecret: Config.get('xero.client_secret'),
            grantType: 'client_credentials',
            // scopes: Config.get('xero.scopes').split(' '), // openid profile email accounting.transactions projects offline_access
            httpTimeout: Config.get('xero.timeout'), // ms
        })
    }

    async createToken() {
        console.log('xero init ...')
        await this.client.initialize()
        console.log('token generating')
        let token = await this.client.getClientCredentialsToken()
        console.log('token setting')
        await this.client.setTokenSet(token)
        return token
    }

    async setToken(token) {
        console.log('xero init ...')
        await this.client.initialize()
        console.log('token setting')
        await this.client.setTokenSet(token)
        return token
    }

    async createInvoices(invoices) {
        const response = await this.client.accountingApi.createInvoices('', invoices)
        return response.body.invoices[0].invoiceID
    }

    async updateInvoices(invoice_id) {
        const response = await this.client.accountingApi.updateInvoice('', invoice_id, { "invoices": [{ "status": "AUTHORISED" }] })
        return response.body.invoices[0].invoiceID
    }

    async createQuotes(quotes) {
        const response = await this.client.accountingApi.createQuotes('', quotes)
        return response.body.quotes[0].quoteID
    }

    async createPurchaseOrders(purchaseOrder) {
        const response = await this.client.accountingApi.createPurchaseOrders('', purchaseOrder)
        return response.body.purchaseOrders[0].purchaseOrderID
    }

    async createPayments(payments) {
        const response = await this.client.accountingApi.createPayments('', payments)
        return response.body
    }
    async getInvoices(id) {
        const response = await this.client.accountingApi.getInvoiceAttachmentById('', payments)
        return response.body
    }
    async getTrackingCategory() {
        const response = await this.client.accountingApi.getTrackingCategories('', undefined, undefined, undefined, { headers: { "Name": "Region" } })
        return response.body
    }
    async createInvoiceAttachment(invoiceID, file) {
        const pathToUpload = root_directory + '/public/invoice_files/' + file;
        const readStream = await fs.createReadStream(pathToUpload);
        // const contentType = mime.lookup(file);
        let extention = file.split('.')
        extention = extention[extention.length - 1]
        let filename = "xero-Invoice." + extention
        const fileAttached = await this.client.accountingApi.createInvoiceAttachmentByFileName('', invoiceID, filename, readStream, {
            headers: {
                "Content-Type": "application/octet-stream"
            },
        });
        return fileAttached
    }

    async deletePayment(payment_id) {
        const response = await this.client.accountingApi.createPayments('', payment_id, { "Payments": [{ "Status": "DELETED" }] })
        return response.body
    }

    async createContact(user) {
        const contacts = {
            contacts: [{
                name: user.first_name + " " + user.last_name + " - " + JSON.stringify(user._id),
                emailAddress: user.email,
                phones: [{
                    phoneNumber: user.phone,
                    phoneType: 'mobile'
                }]
            }]
        }
        const response = await this.client.accountingApi.createContacts('', contacts)
        return response.body
    }
}