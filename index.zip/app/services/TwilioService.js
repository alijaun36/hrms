const Twilio = require('twilio')
/**
 * @class TwilioService
 * @description Service for permissions
 * @howTo
 * - npm install --save twilio
 * - app/hooks.js > boot() > app.loadService('twilio', 'app.services.TwilioService')
 */
module.exports = class TwilioService {

    constructor(app) {
        if (Config.app('debug')) console.log("* TwilioService")
        this.twilio = new Twilio(Config.get('twilio.acountSid'), Config.get('twilio.authToken'))
    }

    async sendSMS(to, body, from) {
        let result = null
        try {
            console.log(to, from, body)

            result = await this.twilio.messages
                .create({
                    body: body,
                    to: to, // Text this number
                    from: from // From a valid Twilio number
                })
                .then(message => message)
        } catch (err) {
            console.log('err', err)
        }

        return result
    }
}