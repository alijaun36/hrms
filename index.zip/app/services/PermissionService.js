/**
 * @class PermissionService
 * @description Service for auto logging exceptions
 * @howTo
 * - npm install --save winston
 * - app/hooks.js > boot() > app.loadService('permissions', 'app.services.PermissionService')
 */
module.exports = class PermissionService {
  constructor(app) {
    if (Config.app('debug')) console.log('* PermissionService')
    this.all = [
      /**
       * User permissions
       */
      'users.getAll',
      'users.getOne',
      'users.create',
      'users.update',
      'users.delete',
      /**
       * User profile permissions
       */
      'users.uploadProfileImage',
      'users.getProfileImage',
      'users.block',
      'users.unblock',
      /**
       * Permission permissions
       */
      'permissions.getAll',
      'permissions.getOne',
      'permissions.create',
      'permissions.update',
      'permissions.delete',
      /**
       * Role permissions
       */
      'roles.getAll',
      'roles.getOne',
      'roles.create',
      'roles.update',
      'roles.delete',
      /**
       * Driver permissions
       */
      'driver.add_vehicle',
      /**
       * Trips permissions
       */
      'trips.getAll',
      'trips.create',
      'trips.getOne',
      'trips.update',
      'trips.delete',
      'trips.search',

      /**
       * Rides permissions
       */
      'rides.getAll',
      'rides.create',
      'rides.getOne',
      'rides.update',
      'rides.delete',
      'rides.cancel',
      'rides.cancelpassenger',
      'rides.complete',
      'rides.rateRideByRider',
      'rides.rateRideByDriver',
      /**
       * Vehicles permissions
       */
      'vehicles.getAll',
      'vehicles.create',
      'vehicles.getOne',
      'vehicles.update',

      /**
       * Support Ticket permissions
       */
      'support_tickets.getAll',
      'support_tickets.create',
      'support_tickets.getOne',
      'support_tickets.update',
      'support_tickets.delete',

      /**
       * Support Message permissions
       */
      'support_messages.getAll',
      'support_messages.create',
      'support_messages.getOne',
      'support_messages.update',
      'support_messages.delete',

      /**
       * Settings permissions
       */
      'settings.getAll',
      'settings.create',
      'settings.getOne',
      'settings.update',
      'settings.delete',

      /**
       * Ride Message permissions
       */
      'ride_messages.getAll',
      'ride_messages.create',
      'ride_messages.getOne',
      'ride_messages.update',
      'ride_messages.delete',
    ]
    this.current_permissions = [] // current logged in user permissions
    this.current_user_id = '' // current logged in user id
  }

  /**
   * @method populate
   * @description Populate the permissions of assgined roles to current logged-in user
   * @param {Object} user
   * @returns null
   */
  async populate(user) {
    // Setting current logged in user id
    this.current_user_id = user._id

    // Skip repopulating from database, if already populated
    if (this.current_permissions.length > 0) return

    // Resolving user model to get roles & permissions
    let user_model = resolveOnce('app.models.UserModel')
    let data = await user_model.findOne({ _id: user._id }).populate('roles')

    // Collecting permission sets
    let permission_sets = []
    data.roles.forEach(role => {
      permission_sets = permission_sets.concat(role.permissions)
    })

    // Assigning current permissions to logged in user
    if (user._id in this.current_permissions) {
      this.current_permissions[user._id] = permission_sets
    } else {
      this.current_permissions[user._id] = []
      this.current_permissions[user._id] = permission_sets
    }
    return this.current_permissions
  }

  /**
   * @method can
   * @description See if user have provided permission assigned to account
   * @param {String} permission
   * @returns {Boolean}
   */
  can(permission) {
    if (!this.current_user_id) return false
    if (!this.current_permissions) return false
    if (this.current_permissions[this.current_user_id] === undefined) return false
    if (this.current_permissions[this.current_user_id].indexOf(permission) > -1) return true
    return false
  }
}
